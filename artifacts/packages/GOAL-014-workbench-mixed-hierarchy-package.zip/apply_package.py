#!/usr/bin/env python3
"""
Apply the GOAL‑014 Mixed Map package to a local cooperative‑cockpit repository.

This script copies replacement files from the package into the repository and
attempts to apply the unified diff.  It creates timestamped `.bak` backups
of any files it replaces.  Run this script from the root of your repository
as follows:

    python3 apply_package.py GOAL-014-workbench-mixed-hierarchy-package

The script assumes the repository contains an `apps/static-mvp/` directory.
"""

import os
import sys
import shutil
import subprocess
from datetime import datetime


def copy_files(src_root: str, dest_root: str) -> None:
    """Recursively copy files from the package's files directory into the repo.
    Create timestamped backups of existing files.
    """
    for dirpath, _, files in os.walk(src_root):
        for filename in files:
            src_file = os.path.join(dirpath, filename)
            rel_path = os.path.relpath(src_file, src_root)
            dest_file = os.path.join(dest_root, rel_path)
            os.makedirs(os.path.dirname(dest_file), exist_ok=True)
            if os.path.exists(dest_file):
                timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
                backup_file = f"{dest_file}.bak.{timestamp}"
                shutil.copy2(dest_file, backup_file)
                print(f"Backed up {dest_file} to {backup_file}")
            shutil.copy2(src_file, dest_file)
            print(f"Copied {src_file} to {dest_file}")


def apply_patch(patch_path: str) -> None:
    """Attempt to apply a unified diff using git apply.  Warn on failure."""
    if not os.path.isfile(patch_path):
        return
    try:
        subprocess.run(["git", "apply", patch_path], check=True)
        print("Patch applied successfully.")
    except Exception as exc:
        print(f"Warning: failed to apply patch automatically. Please apply manually: {exc}")


def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python3 apply_package.py <package_dir>")
        sys.exit(1)
    package_dir = sys.argv[1]
    # Check repository root
    if not os.path.isdir("apps/static-mvp"):
        print("Error: This script must be run from the root of the cooperative-cockpit repository.")
        sys.exit(1)
    files_dir = os.path.join(package_dir, "files")
    if os.path.isdir(files_dir):
        copy_files(files_dir, ".")
    patch_file = os.path.join(package_dir, "PATCH_UNIFIED.diff")
    apply_patch(patch_file)


if __name__ == "__main__":
    main()