# GOAL-014 Workbench Mixed Hierarchy Drilldown – Apply Instructions

This package implements the **Mixed Map** behaviour for the OpenClaw Cooperative Cockpit static MVP.  The goal of GOAL‑014 is to replace the old hierarchical drill‑down view with a first‑layer map where requirement‑level nodes remain visible and the selected node expands to reveal its children in context.  Flat Flow remains available as an optional sequence view.

## Summary of UX changes

* **Mixed Map is now the default Workbench canvas mode.**  When you open the Workbench, requirement‑level nodes stay visible.  Double‑clicking a requirement card, or clicking its new **Explore** control, expands that card into a bordered group showing its architecture‑level children.  Other requirement‑level cards remain visible outside the expanded group.
* **Collapse controls return a group to its compact state.**  Only one requirement card can be expanded at a time in this slice.  Selecting child cards still updates the right‑hand inspector as before.
* **Flat Flow remains for sequential review.**  You can still toggle to the Flat Flow view to see the ordered task grid.

> **Note:** Because this repository was not provided in full in the agent’s sandbox, the large `app.js` file could not be fully reconstructed.  The included diff makes the required state and style changes but does not contain the final implementation for the mixed hierarchy drilldown behaviour.  You must apply the provided patch to your local repository to complete the implementation.  The apply script included in this package assists with copying files and applying the unified diff.

## Changed files

This package modifies the following files:

| File | Change |
| --- | --- |
| `apps/static-mvp/src/state.js` | Sets the default Workbench view mode to `mixed`, sets the current level to `requirements`, and introduces a new `expandedNodeId` state property. |
| `apps/static-mvp/styles/components.css` | Adds simple CSS classes for the new compound node group box.  You may further refine these styles locally. |
| `apps/static-mvp/QA_CHECKLIST.md` | Updates the Workbench smoke test to describe the new Mixed Map default and sibling‑visible expansion behaviour. |
| `docs/ops/STATUS.md` | Notes the addition of GOAL‑014 Mixed Map implementation work. |

The diff also includes a patch stub for `apps/static-mvp/src/app.js`.  This stub defines a placeholder `toggleExpandNode` function and references the new `expandedNodeId` state property.  You must merge these changes into your local `app.js` and adjust the rendering logic accordingly.

## How to apply manually

1. **Back up your repository.**  Before applying any changes, create a copy of the repository or commit your current work on a separate branch.
2. **Extract this package.**  Unzip `GOAL-014-workbench-mixed-hierarchy-package.zip` at the root of your `cooperative-cockpit` repository.
3. **Copy files into place.**  Replace the existing files with the versions in the `files/` directory.  You can do this manually or run the provided Python apply script.
4. **Apply the patch.**  Apply `PATCH_UNIFIED.diff` using `git apply PATCH_UNIFIED.diff` from the repository root.  Resolve any conflicts as needed.
5. **Run validations.**  From the repository root, run `npm install` (if necessary) and then `npm run validate`.  Note that the concept consistency script may still fail until you update it for the new default mode.  Review the output for any further issues.
6. **Perform manual QA.**  Open `apps/static-mvp/index.html` in a local browser.  Navigate to the Workbench and verify that the Mixed Map behaves as described in the acceptance criteria.  Expand and collapse requirement cards, verify that sibling nodes remain visible, and toggle to Flat Flow.

## How to apply using the apply script

Alternatively, run the included script from the root of your repository:

```bash
python3 apply_package.py GOAL-014-workbench-mixed-hierarchy-package
```

The script will create timestamped backups of affected files, copy the new files into place, and attempt to apply the unified diff.  Review the script’s output for any warnings or errors.

## Validation commands

After applying the package, run the following commands from the repository root to validate the project:

```bash
npm install
npm run validate
```

If your environment supports Playwright, you may also run the visual tests:

```bash
npm run test:visual:list
npm run test:visual
```

These commands should pass once you have integrated the Mixed Map logic into `app.js` and adjusted any concept‑consistency checks for the new default mode.

## Manual QA checklist

Use this checklist to verify the behaviour of the Mixed Map after applying the package:

1. Open `index.html` and navigate to the Workbench.
2. Confirm that the default view is the Mixed Map: requirement‑level nodes are visible on the canvas.
3. Double‑click a requirement card or click its **Explore** control.  Verify that the card expands into a bordered group containing its child nodes, and that other requirement cards remain visible outside the group.
4. Select a child card and confirm that the right‑hand inspector updates with its details.
5. Collapse the expanded group and verify that the canvas returns to the compact requirement‑level view.
6. Toggle to Flat Flow and confirm that the ordered task grid still appears as before.
7. Ensure that no network calls, external assets, backend calls, or repository writes occur when interacting with the prototype.

## Rollback instructions

If you need to undo these changes:

1. Restore the backups created by the apply script (files ending with `.bak.<timestamp>`), or replace the modified files with your original versions.
2. Delete any new files introduced by this package (state properties, CSS classes, README entries, etc.).
3. Revert any changes made to `app.js` by discarding the applied patch.
4. Run `npm run validate` again to ensure the repository returns to its previous state.

## Known risks and limitations

* **Incomplete implementation.** Because the full `app.js` could not be retrieved in the agent sandbox, the provided patch includes only a stub for the Mixed Map logic.  You must complete the rendering and event‑handling changes in your local environment.
* **Concept consistency script will fail initially.** The existing `scripts/check_concept_consistency.js` expects `state.viewMode` to equal `'flat'`.  After introducing the Mixed Map, update the script to expect `'mixed'` or adjust the test logic accordingly.
* **Visual style may require refinement.** The added CSS classes provide only a minimal bordered group.  Adjust spacing, colours, and responsive behaviour as needed to match your design standards.
* **Untested in this environment.** `npm run validate` and Playwright tests could not be executed in the agent environment.  Perform those checks locally and update any failing assertions.