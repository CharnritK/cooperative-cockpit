# 06 — MVP Architecture Handoff

Status: planning handoff only. Not implementation authorization.

## Goal

Design a static evidence-linked code-object explorer surface for Cooperative Cockpit, then prepare approval-gated prototypes for parser and LSP enrichment.

## Phase 0: static mock explorer

### Allowed intent

Demonstrate the product concept using static JSON fixtures and existing static MVP constraints.

### Requirements

| id | requirement | acceptance criteria |
|---|---|---|
| R-P0-001 | Display code-object tree from fixture | User can select file/class/function nodes |
| R-P0-002 | Display bounded selected-object graph from fixture | Graph never shows whole repo by default |
| R-P0-003 | Display evidence inspector | Node/edge selection shows file path and line range |
| R-P0-004 | Display findings and annotations separately | Facts, findings, decisions, annotations are visually distinct |
| R-P0-005 | Preserve static guardrails | No backend, API, database, runtime process, external connector, repo write, or new dependency unless Point approves |

## Phase 1: local parser prototype

Point-lock required.

Candidate work:
- Tree-sitter/language-parser extraction outside production static MVP.
- Generate `CodeObject`, `RelationEdge`, `EvidenceRef` JSON from sample repo.
- Validate line spans, stable IDs, and parser performance.

## Phase 2: local LSP bridge prototype

Point-lock required.

Candidate work:
- Local process talks to language server.
- Browser or script requests document symbols, references, definitions, call/type hierarchy.
- Outputs fixture-compatible graph JSON.

## Non-goals

- No full program analysis.
- No CodeQL/Joern/Kythe/SCIP backend.
- No runtime tracing.
- No workflow canvas.
- No editor/code mutation.
- No external code upload.

## Validation commands

Recommended, not executed by this package:

```bash
npm run validate
```

## Stop conditions

- New dependency needed without Point-lock.
- Local process needed without Point-lock.
- Backend/API/database/auth/deployment suggested.
- Source code would leave local environment.
- Tests or acceptance criteria cannot be defined.
