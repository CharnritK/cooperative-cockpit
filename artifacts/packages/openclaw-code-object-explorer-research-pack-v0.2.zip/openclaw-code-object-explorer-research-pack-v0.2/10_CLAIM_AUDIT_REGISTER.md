# 10 — Claim Audit Register

Status: v0.2.

| claim_id | claim | source/report | disposition | reason | evidence strength | risk if wrong | follow-up verification |
|---|---|---|---|---|---|---|---|
| CA-001 | Build custom CodeObject/RelationEdge/EvidenceRef model | ChatGPT Deep Research | Adopted | Central missing product layer | Partial | Wrong schema could constrain future integrations | Schema review with sample repos |
| CA-002 | Tree-sitter is best parser candidate | ChatGPT + Gemini | Modified | Good candidate, but dependency not approved | Partial | Parser choice may fail on target languages | Official docs + prototype |
| CA-003 | LSP should enrich semantics | ChatGPT + Gemini | Modified | Useful but runtime bridge is gated | Partial | Bridge may violate static guardrails | Point-lock + language-server pilot |
| CA-004 | D3/Cytoscape are best renderers | ChatGPT + Gemini | Modified | Good candidates, dependencies gated | Partial | Bundle/performance issues | Dependency review + UX prototype |
| CA-005 | SCIP is preferred enterprise index direction | ChatGPT + Wen | Adopted for enterprise | Stronger than LSIF in primary research | Partial | Enterprise architecture may pick wrong backbone | Official SCIP/Sourcegraph review |
| CA-006 | Kythe should back enterprise storage | Wen | Modified | Useful reference, not fixed decision | Needs Verification | Over-complex enterprise design | Architecture spike |
| CA-007 | CodeQL/Joern should power security review | ChatGPT + Wen | Deferred | Strong tools but non-MVP | Partial | Security wedge may need earlier integration | Security roadmap decision |
| CA-008 | CPG should be foundational model | Wen | Rejected for MVP | Conflicts with lightweight MVP | Weak for MVP | Overbuild and infra creep | Keep as enterprise/security reference |
| CA-009 | React Flow is acceptable core renderer | Comparator implication | Rejected | Workflow-builder semantic risk | Partial | UI drift into workflow canvas | Use only with explicit design review |
| CA-010 | Quantified productivity/cycle-time improvements | Wen | Quarantined | Unsupported in provided package | Weak | Misleading business claims | Require primary studies or remove |
| CA-011 | Sourcetrail is archived/unmaintained | ChatGPT | Needs Verification | Needs live official repo check | Needs Verification | Wrong dependency decision | Verify official repo |
| CA-012 | Backend/API/datastore prohibited in current phase | ChatGPT source context | Adopted | Core guardrail in source package | Supported by provided source context | Guardrail violation | Point review before persistence |
