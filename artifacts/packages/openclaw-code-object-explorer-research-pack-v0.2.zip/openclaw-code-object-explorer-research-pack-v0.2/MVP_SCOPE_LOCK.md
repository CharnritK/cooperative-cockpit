# MVP Scope Lock

Status: v0.2 guardrail artifact.  
Purpose: split the research recommendation into implementation-safe phases.

## Current static repo boundary

The current Cooperative Cockpit repo phase remains static, offline, mock-data only, and review-oriented. This package does not authorize implementation.

## Phase split

| phase_id | phase | description | allowed now? | Point-lock required? |
|---|---|---|---|---|
| P0 | Static mock explorer | Mock code-object explorer surface using static JSON fixtures and no new runtime/dependencies | Yes, if within existing static guardrails | If new pages/dependencies/object-model changes are needed |
| P1 | Local parser prototype | Tree-sitter or language-native parser experiment outside production UI | No | Yes |
| P2 | Local LSP bridge prototype | Local process/Node bridge to language servers | No | Yes |
| P3 | Enterprise indexing architecture | SCIP/Kythe/CodeQL/Joern/persistent index/backend | No | Yes |

## MVP non-goals

- No backend/API/database/auth/deployment.
- No live agent orchestration.
- No external connectors.
- No repository writes by the app.
- No full-repo graph canvas.
- No visual workflow builder.
- No deep control-flow/data-flow/security engine in the static MVP.
- No AI claim without EvidenceRef.

## Approved-next product wedge

Evidence-linked code-object review:
1. Select a code object.
2. See bounded relationships.
3. Inspect exact evidence.
4. Attach finding or annotation.
5. Produce a review/handoff packet.

## Stop conditions

Stop and ask for Point review if:
- a new dependency is needed;
- a runtime process is needed;
- a backend/API/database/auth/deployment is suggested;
- product semantics drift into workflow orchestration;
- a claim lacks line-level evidence;
- an implementation step touches repo files without an approved Codex goal.
