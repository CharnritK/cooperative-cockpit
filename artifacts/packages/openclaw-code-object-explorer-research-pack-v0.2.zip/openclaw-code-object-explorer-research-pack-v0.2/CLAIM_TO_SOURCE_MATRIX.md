# Claim-to-Source Matrix

Status: v0.2 canonical claim mapping.

Important limitation: this package generation did **not** perform live web verification. Official URLs are included in `OFFICIAL_SOURCE_REGISTER.md`, and claims requiring current maintenance, license, or exact capability are marked Partial or Needs Verification until verified.

| claim_id | claim | topic | source_ids | support_status | may support final rationale? | notes |
|---|---|---|---|---|---|---|
| CL-001 | Mature building blocks exist, but no complete off-the-shelf artifact-first evidence-linked code-object explorer was identified. | Product landscape | SRC-000; OS-001..OS-032 | Partial | Yes, as strategic rationale | Live market scan not performed in v0.2 packaging. |
| CL-002 | The strongest product approach is hybrid: custom review/evidence layer and bounded UI on top of mature extraction/indexing primitives. | Architecture | SRC-000; OS-001; OS-003; OS-013; OS-015 | Partial | Yes, with caveat | Validated by primary report; implementation still gated. |
| CL-003 | Current repo phase should be treated as static/mock/offline and not as approval for parser/LSP dependencies or runtime processes. | Repo guardrail | SRC-000 | Supported by provided source context | Yes | No repo mutation performed. |
| CL-004 | Tree-sitter is the leading candidate for structural extraction in an approved local parser prototype. | Parsing | SRC-000; OS-001; OS-002 | Partial | Yes, with caveat | Needs live license/maintenance/bundle verification before dependency gate. |
| CL-005 | LSP can enrich object graphs with symbols, definitions, references, implementations, call hierarchy, type hierarchy, folding ranges, and semantic tokens where servers support them. | Semantic navigation | SRC-000; OS-003 | Partial | Yes, with caveat | Capability varies by language server; requires P2 gate. |
| CL-006 | D3 hierarchy is a good fit for object trees and treemaps. | Visualization | SRC-000; OS-015 | Partial | Yes, with caveat | Dependency and accessibility review required. |
| CL-007 | Cytoscape.js is a good fit for bounded relationship graphs. | Visualization | SRC-000; OS-013; OS-014 | Partial | Yes, with caveat | Performance and license review required. |
| CL-008 | Graphviz/Mermaid/PlantUML should be export paths rather than primary interactive UI. | Visualization | SRC-000; OS-018; OS-019; OS-020 | Partial | Yes, with caveat | Static export only; security sanitization required. |
| CL-009 | SCIP is the preferred future direction for enterprise code-intelligence indexing over LSIF in greenfield work. | Enterprise indexing | SRC-000; OS-004; OS-005; OS-006; OS-021 | Partial | Yes, with caveat | Needs current official review and ops feasibility. |
| CL-010 | Kythe should be deferred to enterprise architecture exploration, not MVP dependency. | Enterprise indexing | SRC-000; OS-007; OS-008 | Partial | Yes, with caveat | High serving/storage complexity. |
| CL-011 | CodeQL and Joern are powerful for security/static analysis but should be deferred unless security review becomes the launch wedge. | Static analysis | SRC-000; OS-009; OS-010; OS-011; OS-012 | Partial | Yes, with caveat | Compute and dependency complexity. |
| CL-012 | React Flow should not be primary UI because of workflow-builder semantics risk. | UX risk | SRC-000 | Partial | Yes, with caveat | Could be revisited for non-core diagrams. |
| CL-013 | Sourcetrail should be inspiration only, not dependency, unless current repo status and license are verified. | Reference project | SRC-000; OS-023 | Needs Verification | No | Verify archived/current status before any claim. |
| CL-014 | Comparator reports support the two-track MVP/enterprise framing but include unsupported or overly aggressive claims. | Source audit | SRC-001; SRC-002 | Partial | Yes, for source handling | Quantified claims and CPG-first claims downgraded. |
| CL-015 | AI-generated review claims must be attached to evidence refs and human review status. | AI review | SRC-000; SRC-002 | Partial | Yes, with caveat | Implementation requires security/privacy review gate. |

## Claims downgraded from v0.1

| downgraded claim | new status | reason |
|---|---|---|
| “All listed tools are current and supported.” | Needs Verification | Requires live official-source check. |
| “Tree-sitter WASM is approved for MVP.” | Needs Verification | Dependency approval and performance testing required. |
| “LSP bridge is MVP-compatible.” | Partial / gated | It is local, but still a runtime process requiring Point-lock. |
| “CodeScene/SciTools/SonarQube details are implementation-ready.” | Needs Verification | Commercial docs/licensing/current features must be verified. |
| “CPG should be foundational data model.” | Rejected for MVP | Conflicts with lightweight MVP; retained only as enterprise/security reference. |
