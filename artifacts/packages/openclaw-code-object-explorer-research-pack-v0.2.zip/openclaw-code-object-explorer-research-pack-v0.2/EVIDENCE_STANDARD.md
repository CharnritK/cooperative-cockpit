# Evidence Standard

Status: Canonical evidence policy for this research package.

## Support statuses

| status | meaning | may support recommendation? |
|---|---|---|
| Supported | Directly supported by a primary or official source and not contradicted. | Yes |
| Partial | Supported by credible evidence but limited, indirect, or not fully current. | Yes, with caveat |
| Weak | Comparator-only, vendor-biased, stale, unclear, or not directly evidenced. | No |
| Needs Verification | Plausible but requires live source check, prototype, or legal/license review. | No |
| Unsupported | No usable evidence. | No |
| Contradicted | Conflicting evidence materially affects the claim. | No |

## Evidence handling rules

- Final recommendations may rely only on Supported or Partial claims.
- Weak, Needs Verification, Unsupported, or Contradicted claims must appear only in risks, gaps, validation tasks, or review gates.
- Comparator reports are never final authority by themselves.
- The ChatGPT Deep Research report is the primary synthesis source, but tool/product claims still require official-source mapping.
- Current maintenance, license, and version claims require live verification before implementation.
- Transient chat citation markers are not repo-persistable evidence and were removed from canonical docs.

## EvidenceRef rule for product design

Every future product node, edge, review finding, and AI claim must include an `evidence_refs` array pointing to exact file path, line range, snippet hash, and optional commit hash.

## Review gate

| gate_id | reviewer | review_scope | pass_condition | fallback |
|---|---|---|---|---|
| RG-EVIDENCE-001 | Point or delegated research reviewer | Official source register, claim matrix, unsupported claims | Claims used in decision rationale are Supported or Partial | Downgrade package readiness and move claims to Gap Backlog |
| RG-EVIDENCE-002 | Technical lead | Dependency claims and architecture feasibility | Tool claims verified against current official docs | Defer the dependency and use mock/static substitute |
