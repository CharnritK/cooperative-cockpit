# 11 — Source Audit Register

## Local sources

| source_id | source | type | credibility | bias risk | used for | notes |
|---|---|---|---|---|---|---|
| SRC-000 | sources/SOURCE_00_CHATGPT_DEEP_RESEARCH.md | Primary research report | High for synthesis | Medium | Main recommendation | Transient citations removed; official mapping added separately |
| SRC-001 | sources/SOURCE_01_GEMINI_COMPARATOR.md | Comparator report | Medium | Medium | Alternative wording, risks, two-track framing | Claims cannot drive final rationale alone |
| SRC-002 | sources/SOURCE_02_WEN_COMPARATOR.md | Comparator report | Medium | High | CPG/enterprise ideas | Aggressive CPG and quantified claims downgraded |

## Official sources

See `OFFICIAL_SOURCE_REGISTER.md`.

## Source quality decisions

| decision | rationale |
|---|---|
| Comparator reports are secondary | They include useful insights but contain weak, unverified, or over-broad claims |
| Official source URLs replace placeholder source entries | Source register now contains official URLs or local source paths |
| Live source verification remains open | Web verification was not performed in this packaging run |
| Primary report is retained as source | The actual ChatGPT Deep Research report is included in `sources/` |
