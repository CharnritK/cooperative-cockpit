# OpenClaw Code-Object Explorer Research Pack v0.2

Generated: 2026-06-01  
Readiness: **READY_FOR_REVIEW / NOT_READY_FOR_IMPLEMENTATION**  
Artifact type: research-to-build package  
Repo target: `CharnritK/cooperative-cockpit`

## Purpose

This package revises v0.1 into a repo-persistable research package for the Cooperative Cockpit evidence-linked code-object explorer.

The package is designed to support review and planning before implementation. It does **not** authorize code changes, dependency additions, backend/API/database/auth/deployment work, external connectors, live agents, repo writes, commits, pushes, or PRs.

## What changed from v0.1

1. Added the actual ChatGPT Deep Research report as `sources/SOURCE_00_CHATGPT_DEEP_RESEARCH.md`.
2. Added Gemini and Wen reports as comparator-only sources.
3. Replaced placeholder source URLs with official source targets or local source paths.
4. Downgraded unsupported comparator claims to Partial, Weak, or Needs Verification.
5. Removed transient chat citation markers from canonical docs.
6. Added official source coverage for required tools/products.
7. Split MVP into static mock explorer, local parser prototype, local LSP bridge prototype, and enterprise indexing architecture.
8. Added explicit Point-lock gates for dependencies, runtime processes, backend work, external connectors, MCP, and repo writes.
9. Added:
   - `MVP_SCOPE_LOCK.md`
   - `DEPENDENCY_GATE.md`
   - `SECURITY_PRIVACY_REVIEW_GATE.md`
   - `EVIDENCE_STANDARD.md`
   - `OFFICIAL_SOURCE_REGISTER.md`
   - `CLAIM_TO_SOURCE_MATRIX.md`

## Core recommendation

Build the product-specific evidence layer and bounded review UI. Integrate mature extraction/rendering primitives only after gates. Defer persistent indexing and deep semantic/security engines until enterprise phase. Avoid workflow-canvas metaphors.

## Source priority

1. `sources/SOURCE_00_CHATGPT_DEEP_RESEARCH.md`
2. `sources/SOURCE_01_GEMINI_COMPARATOR.md`
3. `sources/SOURCE_02_WEN_COMPARATOR.md`
4. `OFFICIAL_SOURCE_REGISTER.md`
5. Repo/product canon supplied in the research inputs

## Recommended repo destination

- Unzipped package: `artifacts/deep-research/openclaw-code-object-explorer/openclaw-code-object-explorer-research-pack-v0.2/`
- Zip: `artifacts/packages/openclaw-code-object-explorer-research-pack-v0.2.zip`

## Required review before persistence

| gate | reviewer | pass condition |
|---|---|---|
| Evidence review | Point or research reviewer | Claim matrix uses only Supported/Partial claims in rationale |
| Repo guardrail review | Point | No implied implementation, dependencies, backend, connector, or repo write |
| Security/privacy review | Security/privacy reviewer if real code ingestion is planned | Source snippets and metadata handling are safe |
| Dependency review | Technical reviewer | Every dependency has license/current-status verification |

## Quick file map

- `00_EXECUTIVE_DECISION_MEMO.md` — decision summary.
- `01_FINAL_SYNTHESIZED_RESEARCH_REPORT.md` — canonical synthesis.
- `MVP_SCOPE_LOCK.md` — implementation-safe phase split.
- `DEPENDENCY_GATE.md` — dependency approval gates.
- `SECURITY_PRIVACY_REVIEW_GATE.md` — code ingestion and evidence privacy gates.
- `OFFICIAL_SOURCE_REGISTER.md` — official source coverage.
- `CLAIM_TO_SOURCE_MATRIX.md` — claim support mapping.
- `14_PROMPT_FOR_NEXT_CODEX_GOAL.md` — future persistence handoff prompt.
