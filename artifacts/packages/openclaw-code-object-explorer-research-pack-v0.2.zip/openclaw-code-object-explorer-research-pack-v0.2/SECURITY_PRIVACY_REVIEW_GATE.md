# Security and Privacy Review Gate

Status: v0.2 required review artifact.

The code-object explorer is a code ingestion and evidence display system. Even local prototypes can expose proprietary code, secrets, credentials, security vulnerabilities, or confidential design details.

## Sensitive data in scope

- Source code and snippets.
- File paths that reveal customer/project names.
- Commit metadata and author identities.
- Secrets inside code, config, tests, or comments.
- Security vulnerabilities or exploit details.
- AI-generated findings and annotations.

## Privacy design requirements

1. Default to local-only processing.
2. Do not send source code to external services.
3. Run secret scanning before displaying or exporting snippets.
4. Store snippet hashes, not full snippets, where possible.
5. Include commit hash and line range for evidence.
6. Separate facts from findings and AI annotations.
7. Gate every export/handoff that contains source snippets.

## Review gates

| gate_id | reviewer | review_scope | pass_condition | fallback |
|---|---|---|---|---|
| RG-SEC-001 | Security reviewer | Code ingestion, snippet display, export behavior | No external code shipment; secrets redacted; evidence access bounded | Block real repo ingestion; use mock fixtures |
| RG-SEC-002 | Privacy/data owner | Commit metadata and author fields | Data minimization; no unnecessary PII exposure | Remove author metadata from MVP |
| RG-SEC-003 | Point | Any AI annotation workflow | Every AI claim has EvidenceRef and human review status | Disable AI annotations; use static examples |
| RG-SEC-004 | Legal/compliance reviewer if commercialized | Dependency licenses and customer code handling | License compatibility and customer-data policy approved | Defer commercial release |

## Stop conditions

- A secret appears in extracted evidence.
- A tool requires cloud upload of source code.
- A generated finding includes exploit instructions.
- The product cannot distinguish facts from AI claims.
- User access/permission model is undefined for enterprise scope.
