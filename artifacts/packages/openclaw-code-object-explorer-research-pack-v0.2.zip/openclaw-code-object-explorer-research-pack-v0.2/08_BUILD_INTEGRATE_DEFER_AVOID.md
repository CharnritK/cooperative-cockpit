# 08 — Build / Integrate / Defer / Avoid

| item | recommendation | phase | rationale | evidence strength | Point-lock? |
|---|---|---|---|---|---|
| CodeObject model | Build | P0 | Missing product-specific substrate | Partial/primary | Product review |
| RelationEdge model | Build | P0 | Needed for bounded graph views | Partial/primary | Product review |
| EvidenceRef model | Build | P0 | Required for traceability | Partial/primary | Product review |
| ReviewFinding | Build | P0 | Core review workflow | Partial/primary | Product review |
| AgentAnnotation | Build gated | P0/P2 | AI claims need evidence and human review | Partial | Yes |
| Static fixtures | Build | P0 | Safest current demonstration path | Supported by guardrails | Maybe |
| Tree-sitter | Integrate after gate | P1 | Strong structural parser candidate | Partial | Yes |
| TypeScript/Babel parser | Integrate selectively after gate | P1 | Language-specific fidelity | Partial | Yes |
| Python ast/LibCST | Integrate selectively after gate | P1 | Python fidelity | Partial | Yes |
| LSP | Integrate after gate | P2 | Semantic enrichment | Partial | Yes |
| D3 hierarchy | Integrate after gate | P1/P2 | Tree/treemap view | Partial | Yes |
| Cytoscape.js | Integrate after gate | P1/P2 | Bounded graph view | Partial | Yes |
| ELK/elkjs | Integrate after gate | P1/P2 | Layered graph layout | Partial | Yes |
| Graphviz | Integrate later | P2+ | Static export | Partial | Yes |
| Mermaid | Integrate later | P2+ | Documentation export | Partial | Yes |
| PlantUML | Integrate later | P2+ | Documentation export | Partial | Yes |
| SCIP | Defer | P3 | Enterprise index | Partial | Yes |
| Kythe | Defer | P3 | Enterprise interchange/storage | Partial | Yes |
| CodeQL | Defer | P3/security | Security review engine | Partial | Yes |
| Joern/CPG | Defer | P3/security | Deep semantic/security analysis | Partial | Yes |
| React Flow core UI | Avoid | All | Workflow-builder metaphor risk | Partial | Yes if reconsidered |
| Whole-repo graph | Avoid | All | Hairball risk | Partial | No |
| Backend/API/database/auth/deploy | Avoid now | P0-P2 | Current guardrails | Supported by source context | Yes |
