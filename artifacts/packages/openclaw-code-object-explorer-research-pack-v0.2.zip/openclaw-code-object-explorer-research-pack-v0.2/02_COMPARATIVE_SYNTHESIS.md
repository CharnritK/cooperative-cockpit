# 02 — Comparative Synthesis

## Source roles

| source | role | how used |
|---|---|---|
| ChatGPT Deep Research | Primary | Main recommendation and architecture thesis |
| Gemini comparator | Secondary | Two-track MVP/enterprise framing and risk notes |
| Wen comparator | Secondary | CPG/SCIP/Kythe/enterprise ideas and visual architecture references |

## Agreement

All three sources support the broad direction that mature pieces exist but need a custom product layer for Cooperative Cockpit. They generally agree on:

- Tree-sitter or parsers for local structure.
- LSP as semantic enrichment.
- Bounded graph views rather than whole-repo hairballs.
- Custom schema for objects, relations, evidence, and findings.
- Persistent indexing reserved for enterprise scale.
- CodeQL/Joern/CPG as powerful but too heavy for the initial wedge.

## Disagreement and resolution

| topic | comparator claim | resolution |
|---|---|---|
| CPG as foundational architecture | Wen report pushes CPG heavily | Rejected for MVP, retained for enterprise/security reference |
| Local LSP bridge as MVP | Gemini treats bridge as core MVP | Reclassified as P2 Point-lock prototype |
| React Flow / workflow-style node UI | Some references mention React Flow | Avoid as primary metaphor |
| Browser parser dependencies | Comparators assume dependencies are acceptable | Dependency gate required |
| Quantified productivity/cycle claims | Wen includes strong quantified claims | Needs Verification; not used in rationale |

## Adopted position

The v0.2 package adopts the ChatGPT Deep Research thesis: build the missing evidence/review layer, integrate mature tools only after gates, and defer heavy indexing/analysis.

Comparator reports are preserved as sources but do not independently support final recommendations.
