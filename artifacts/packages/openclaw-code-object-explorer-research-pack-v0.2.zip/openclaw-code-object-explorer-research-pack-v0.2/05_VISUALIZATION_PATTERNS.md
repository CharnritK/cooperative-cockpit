# 05 — Visualization Patterns

## Recommended views

| view | purpose | data | renderer | phase | risk |
|---|---|---|---|---|---|
| Code object tree | Browse hierarchy | CodeObject parent_id | Static HTML / D3 after gate | P0/P1 | Large trees |
| Symbol outline | File-level summary | CodeObject symbols | Static list / LSP later | P0/P2 | Server variability |
| Selected-object graph | Contextual relation view | RelationEdge radius | Static SVG / Cytoscape after gate | P0/P1 | Hairball |
| Call hierarchy | Caller/callee review | calls edges | Cytoscape/ELK after gate | P2 | Incomplete calls |
| Import graph | Module dependencies | imports edges | Cytoscape/Graphviz after gate | P1/P2 | Dense graph |
| Type hierarchy | Inheritance review | extends/implements edges | ELK after gate | P2 | Language-specific |
| Control-flow view | Block-level logic | CFG | Future | Enterprise | Heavy analysis |
| Data-flow view | Security/data lineage | DFG/CPG | Future | Enterprise | Heavy analysis |
| Treemap/hotspot | Size/risk map | metrics/churn | D3 after gate | P1/P3 | Misleading metrics |
| Evidence inspector | Source proof | EvidenceRef | Static HTML | P0 | Sensitive snippets |
| Finding overlay | Review issues | ReviewFinding | Static HTML | P0 | Clutter |
| AI annotation layer | Agent claims | AgentAnnotation | Static fixture first | P0/P2 | Hallucination |
| Boundary map | Architecture constraints | tags/edges | Future | Enterprise | Manual taxonomy |

## Default interaction

1. Select object.
2. Show bounded graph radius 1.
3. Show evidence snippet.
4. Show findings/annotations separately.
5. Allow expansion only by explicit user action.

## Avoided patterns

- Whole-repo graph canvas.
- Workflow-node canvas.
- Visual programming/editor behavior.
- AI-generated diagram without source evidence.
