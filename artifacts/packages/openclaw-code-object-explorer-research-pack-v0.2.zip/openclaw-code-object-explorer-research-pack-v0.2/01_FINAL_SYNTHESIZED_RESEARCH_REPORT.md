# 01 — Final Synthesized Research Report

## Executive summary

The final recommendation is a phased hybrid architecture.

OpenClaw Cooperative Cockpit should not attempt to build a complete static-analysis platform from scratch, and it should not adopt a heavyweight code-intelligence backend as the first implementation step. The practical path is to build a custom evidence-linked code-object review layer and use mature tools as gated inputs.

The key product wedge is **evidence-linked code-object review**: a human and AI agent can point to the same object, relation, snippet, finding, annotation, and decision without turning the interface into a workflow builder.

## Source posture

The primary source is the ChatGPT Deep Research report included in `sources/SOURCE_00_CHATGPT_DEEP_RESEARCH.md`. The Gemini and Wen reports are included as comparator sources only. Official source targets are listed in `OFFICIAL_SOURCE_REGISTER.md`. Since live web verification was not performed during this packaging run, current-version, license, maintenance, and exact-capability claims are gated for verification.

## Terminology map

| term | working definition |
|---|---|
| AST | Abstract syntax tree for source code structure |
| CST | Concrete syntax tree preserving more syntax detail |
| Symbol graph | Named entities and definitions/references |
| Call graph | Caller/callee relationship graph |
| Dependency graph | Imports, packages, modules, or architectural dependencies |
| CFG | Execution path graph |
| Data-flow graph | Value propagation graph |
| PDG | Program dependence graph combining data/control dependence |
| CPG | Code property graph combining AST/CFG/PDG layers |
| Code intelligence index | Persistent index for semantic navigation |
| Evidence-linked review | Review model where every claim points to exact source evidence |

## Technology landscape

### Parser and structure extraction

Tree-sitter and language-native parser APIs are the strongest starting points. Tree-sitter is the most attractive generic parser candidate, while TypeScript Compiler API, Babel, Python `ast`, LibCST, Roslyn, JavaParser/Spoon, and Clang/LLVM remain language-specific options.

MVP stance: use static fixtures now. Prototype parsers only after dependency approval.

### Semantic navigation

LSP is the right enrichment protocol for document symbols, definitions, references, implementations, call hierarchy, type hierarchy, folding ranges, and semantic tokens. However, LSP quality varies by language server, and a local LSP bridge is a runtime process, so it cannot be treated as current static MVP behavior.

MVP stance: define schema now; treat LSP as an approval-gated P2 prototype.

### Persistent indexing

SCIP is the strongest future direction for enterprise code intelligence. LSIF is a legacy comparison point. Kythe is useful as an enterprise reference for graph storage/interchange. These require indexing, storage, serving, and operational infrastructure.

MVP stance: defer.

### Deep static analysis

CodeQL and Joern/CPG systems are valuable for security review, taint analysis, and advanced semantic queries. They are not required for the initial comprehension/review wedge and should not be introduced into the static MVP.

MVP stance: defer.

### Visualization

D3 hierarchy fits object tree and treemap views. Cytoscape.js fits bounded relation graphs. ELK can be used for layered layout if approved. Graphviz, Mermaid, and PlantUML are useful export targets. React Flow should be avoided as the primary UI due to workflow-canvas semantic risk.

## Product pattern analysis

| pattern | adopt? | reason |
|---|---|---|
| Object tree + inspector | Yes | Supports hierarchy and evidence review |
| Selected-object neighborhood graph | Yes | Avoids whole-repo hairballs |
| Graph + source split view | Yes | Keeps evidence visible |
| Review finding overlay | Yes | Makes review action-oriented |
| AI annotation layer | Yes, gated | Requires evidence refs and human review |
| Whole-repo graph canvas | No | Low readability |
| Workflow builder metaphor | No | Violates product boundary |
| CPG-first architecture | Not for MVP | Too heavy |

## Recommended object model

The core model should remain simple:

- `CodeObject`
- `RelationEdge`
- `EvidenceRef`
- `ReviewFinding`
- `AgentAnnotation`

The product-specific value is not the parser itself; it is the stable shared substrate that lets humans and AI refer to the same object, edge, evidence, and finding.

## Relationship taxonomy

Use a layered taxonomy:

1. Structural: `contains`, `defines`, `imports`, `exports`
2. Symbol/reference: `references`, `defined_by`, `declares`
3. Call/runtime-intent: `calls`, `called_by`, `throws`, `catches`
4. Type/inheritance: `extends`, `implements`, `overrides`
5. State interaction: `reads`, `writes`, `mutates`
6. Test/review: `tests`, `tested_by`, `violates_boundary`
7. Change/ownership: `owned_by`, `changed_with`
8. Evidence-derived: `derives_from_evidence`

Every edge must carry extraction method, confidence, and evidence refs.

## MVP architecture split

| phase | architecture | status |
|---|---|---|
| Static mock explorer | Static fixtures demonstrating object tree, bounded graph, evidence inspector, findings | Current safe path |
| Local parser prototype | Tree-sitter/language parser extraction to JSON | Point-lock required |
| Local LSP bridge prototype | Runtime bridge to language servers | Point-lock required |
| Enterprise indexing | SCIP/Kythe/backend/security overlays | Deferred |

## Enterprise architecture

A future enterprise stack should separate facts from overlays.

Facts: code objects, symbols, ranges, references, commits, index artifacts.  
Overlays: findings, risk scores, ownership, change coupling, AI annotations, decisions.

Recommended enterprise direction:

- SCIP-backed indexing
- permission-aware evidence retrieval
- multi-repo support
- annotation/finding store
- audit logs
- optional CodeQL/Joern security overlays
- IDE links
- connector layer only after explicit approval

## Final recommendation

Build the evidence-linked code-object model and review UI specification now. Prototype parser and LSP extraction only behind Point-lock gates. Defer enterprise indexing and deep analysis. Avoid workflow-builder metaphors and whole-repo graph hairballs.

Readiness: **READY_FOR_REVIEW / NOT_READY_FOR_IMPLEMENTATION**.
