# SOURCE_00 — ChatGPT Deep Research Report

Source role: Primary source.
Original file: `deep-research-report.md`.
Sanitization note: transient chat/web citation markers were removed because they are not repo-persistable. Use `OFFICIAL_SOURCE_REGISTER.md` and `CLAIM_TO_SOURCE_MATRIX.md` as the canonical source map.

---

# OpenClaw Cooperative Cockpit Code Object Visualization Research

## Executive summary

Mature building blocks **already exist** for most of the problem space, but they exist as **fragments**, not as a ready-made product that matches OpenClaw Cooperative Cockpit’s exact goal. The market and open-source ecosystem already provide mature solutions for syntax extraction, semantic navigation, persisted code-intelligence indexes, graph rendering, hotspot visualization, and security-oriented code graphs. What does **not** appear to exist as a mature off-the-shelf product is an **artifact-first, evidence-linked, review-oriented code-object explorer** where humans and AI agents can share the same object model and where every generated claim is tied to file-and-line evidence. The strongest conclusion is therefore **hybrid**: build a custom review/evidence layer and bounded UI on top of mature extraction and indexing primitives rather than building the full stack from scratch or outsourcing the entire experience to an existing product. 

For the current repository, the product canon is explicitly **static MVP only**, with eight approved pages, a static-only object model, no backend, no API, no auth, no database, no runtime execution, no connectors, and no new dependencies without Point lock. The current canon also fixes the center of gravity on the Workbench/Cockpit canvas and keeps Handoff Packet derived rather than primary. That means this report should be interpreted as a **research-to-build handoff** and not as approval to alter the repository or introduce dependencies today. 

The strongest MVP path is a **bounded, evidence-first explorer** built around a normalized `CodeObject` + `RelationEdge` + `EvidenceRef` model. For extraction, the best lightweight starting point is **Tree-sitter or language-native parser APIs** for structure, optionally enriched with **LSP** features where available for definitions, references, calls, symbols, and type hierarchy. For rendering, the most coherent split is **D3 hierarchy** for object trees and treemaps, with **Cytoscape.js** for bounded neighborhood graphs and **optional Graphviz/Mermaid/PlantUML export** for static snapshots. Deep whole-program engines such as **CodeQL**, **Joern**, **Kythe**, or a full **SCIP-backed persistent code graph service** should be deferred unless the product explicitly expands into security review, cross-repo navigation, or enterprise-scale indexing. 

The assumptions in the prompt mostly hold. A useful MVP **can** be built without full program analysis, because Tree-sitter and language-native parsers give robust file-local structure, while LSP standardizes symbol, definition, reference, implementation, call hierarchy, type hierarchy, folding ranges, and semantic tokens as optional capabilities that can enrich the object model when a server supports them. The design guidance to avoid whole-repo “hairballs” is also strongly supported by mature product practice: JetBrains emphasizes call hierarchies, dependency analysis, and focused paths between selected nodes; CodeScene uses hierarchical hotspot maps and drill-down exploration; Sourcegraph combines search with precise symbol navigation rather than presenting a single monolithic graph. 

The headline recommendations are therefore straightforward. **Build** the normalized code-object schema, evidence model, review overlays, and bounded UI. **Integrate** parser and protocol building blocks. **Defer** heavyweight semantic engines and persistent indexing until the product needs justify them. **Avoid** workflow-builder metaphors, whole-repo free-form graph canvases, and AI claims that are not attached to exact evidence. 

## Terminology map

An **AST** is an abstract syntax tree: it represents the abstract syntactic grammar of source code, not every lexical detail. Python’s `ast` module is a canonical example; Roslyn syntax trees are also intentionally full-fidelity for source representation in the compiler pipeline. By contrast, **Tree-sitter** explicitly produces a **concrete syntax tree** and is designed to update that tree incrementally while code is being edited. 

A **CST** preserves concrete syntactic structure more directly. In this research, Tree-sitter is the most important CST technology because it is incremental, error-tolerant, dependency-free at runtime, and broadly embeddable. That matters for local analysis and for UI interactions that need resilient parsing even on incomplete files. 

A **symbol graph** is a graph centered on named program entities and addressing relations such as declaration, definition, reference, implementation, and hierarchy. LSP supports `documentSymbol`, `workspace/symbol`, definitions, implementations, references, call hierarchy, and type hierarchy as standardized requests or capabilities; SCIP stores symbol definitions, metadata, package ownership, and external-symbol relationships in an index format for code navigation. 

A **call graph** represents caller-to-callee relations. LSP’s call hierarchy is normalized around incoming and outgoing calls, JetBrains exposes caller/callee hierarchies in the IDE, and SciTools Understand provides call trees and call graph variants in its graph system. 

A **dependency graph** represents higher-level code dependencies such as module, package, class, include, or architectural dependencies. JetBrains supports dependency analysis between modules, packages, and classes; OpenGrok is cross-reference and navigation focused; CodeScene adds architectural hotspot and change-coupling views; Doxygen plus Graphviz can emit inheritance and related documentation graphs. 

A **control-flow graph** models execution paths and predicates. The original code-property-graph paper distinguishes AST, CFG, and PDG as classic program representations; SciTools Understand exposes control-flow graphs directly through the API and UI; Joern’s CPG layers can include control-flow and other overlays. 

A **data-flow graph** or **program dependence graph** models how values and control dependencies propagate. The code-property-graph formulation exists precisely to join AST, CFG, and program dependence information into one traversable graph for advanced analysis. This is powerful for security and taint reasoning, but materially heavier than what an MVP review cockpit needs. 

A **code property graph** is a directed, edge-labeled, attributed multigraph that represents code in layered form for querying. Joern implements this model as a practical platform for code, bytecode, and binary analysis, while the original IEEE paper shows why combining AST, CFG, and PDG enables vulnerability mining. 

A **code-intelligence index** is a persisted representation of code semantics intended to answer navigation queries without re-running the analyzer at request time. LSIF was defined as a workspace dump to answer LSP-like requests offline. SCIP is a language-agnostic protocol and index format for code navigation, now under open governance, and Sourcegraph uses it for precise navigation, including cross-repo resolution. Kythe also fits this category, but as an interchange/storage model that expects further processing for serving. 

**Semantic code navigation** means location-aware navigation based on definitions, references, implementations, types, or symbol identity rather than string matching alone. Sourcegraph explicitly contrasts text search with semantic cross-repo navigation; LSP and SCIP are the dominant protocol forms; JetBrains and VS Code expose these capabilities through editor UX. 

**Evidence-linked code review**, in the Cooperative Cockpit sense, should mean that every node, edge, finding, summary, and AI claim resolves back to exact source evidence such as file path, line range, snippet hash, commit hash, or analysis artifact. That aligns well with the current static MVP canon, which already centers Evidence, trace links, Review Run, Findings, and derived Handoff Packet readiness. 

## Technology landscape and comparison matrix

### Landscape by category

For **parsers and syntax extraction**, the leading practical options are Tree-sitter for multi-language incremental CSTs, language-native compiler APIs when you need better symbol fidelity or type information, and CST-preserving libraries such as LibCST when formatting and source positions matter. Tree-sitter is strongest for local responsiveness and incomplete code; TypeScript Compiler API, Roslyn, Clang AST, JavaParser, and Spoon are stronger when you want deeper language-native structure; Python `ast` is lightweight but drops concrete formatting; LibCST adds immutable CST nodes with metadata providers such as exact line/column positions. 

For **editor protocols and semantic navigation**, LSP is the broad interoperability layer. It standardizes document symbols, workspace symbols, definitions, type definitions, implementations, references, folding ranges, call hierarchy, type hierarchy, and semantic tokens. The key limitation is not the protocol but the variability of language-server implementations, because these capabilities are optional and server-provided. 

For **persistent code-intelligence indexes**, LSIF is the older workspace-dump model oriented around persisted LSP-like answers, while SCIP is the newer, more focused code-intelligence protocol that Sourcegraph now treats as the foundation for precise navigation and open governance. Kythe is more ambitious as a language-agnostic interchange/storage system, but its own storage model explicitly says it is for storage rather than serving and expects downstream indexes or serving formats. 

For **deep static-analysis and security graph systems**, CodeQL and Joern are mature but target different problem shapes. CodeQL is a query language and toolchain for code analysis and security-variant discovery. Joern generates code property graphs across multiple languages and supports taint analysis and graph queries. Both are powerful, but they are materially heavier than what is required for a local, review-first MVP. 

For **rendering and layout**, D3 hierarchy is excellent for tree, treemap, icicle, and indented hierarchy views; Cytoscape.js is the best fit in this set for interactive bounded relation graphs; Graphviz is still excellent for deterministic static layout and export; ELK and Dagre are layout engines rather than full UI libraries; React Flow is highly polished for node-based UIs but semantically risks drifting into workflow-builder territory unless carefully constrained; Mermaid and PlantUML are strong text-to-diagram export targets, not ideal as the primary interactive cockpit renderer. 

For **products and references**, Sourcegraph, JetBrains IDEs, VS Code plus LSP, SciTools Understand, CodeScene, OpenGrok, SonarQube, and Sourcetrail are the most useful comparators. They demonstrate mature UX patterns for code navigation, hierarchy, dependency inspection, hotspots, call graphs, cross references, and issue review, but none of them fully combine review findings, governance objects, evidence refs, and AI claim traceability in the way Cooperative Cockpit requires. 

### Comparison matrix for extraction and indexing

| Item | What it gives you | Best fit for local/static MVP | Best fit for enterprise | Recommendation | Primary evidence |
|---|---|---|---|---|---|
| Tree-sitter | Incremental CST, error-tolerant parsing, many languages, embeddable runtime | Strong | Moderate | **Integrate** for structural extraction |  |
| LSP | Standard requests for document/workspace symbols, definitions, implementations, references, call/type hierarchy, folding, semantic tokens | Strong where language server exists | Strong as enrichment layer | **Integrate** as optional semantic enrichment, not sole truth source |  |
| SCIP | Persisted symbol/signature/package metadata for precise navigation and cross-repo resolution | Usually overkill for MVP | Very strong | **Defer for MVP, integrate for enterprise** |  |
| LSIF | Persisted workspace dump for LSP-like navigation; older format | Too heavy for MVP | Legacy/transition use only | **Defer**; prefer SCIP for greenfield enterprise work |  |
| Kythe | Language-agnostic graph storage/schema, analyzers, cross-reference service model | Too heavy | Strong but complex | **Defer** unless you need large-scale interchange and custom serving |  |
| CodeQL | Query-based semantic analysis for vulnerabilities and variants | Weak fit for MVP | Strong for security review | **Defer** unless security review is a primary launch wedge |  |
| Joern | Multi-language code property graphs, taint analysis, security-oriented querying | Weak fit for MVP | Strong for security/static analysis niches | **Defer** unless you need CPG-driven security review |  |
| TypeScript Compiler API | Whole-program TS model, SourceFiles, AST, typechecker, incremental/watch APIs | Strong for TS repos | Strong for TS enterprise | **Integrate** for TS-specific fidelity |  |
| Babel parser | ESTree-like JS/TS-family AST with ranges/tokens | Strong for JS syntax work | Moderate | **Integrate selectively** for JS-focused extraction |  |
| Roslyn | Full-fidelity syntax trees and semantic model for C#/VB | Strong for .NET repos | Strong for .NET enterprise | **Integrate** for C#/.NET |  |
| JavaParser | Java AST and analysis functionality | Strong for Java syntax/object model | Moderate | **Integrate** for lightweight Java work |  |
| Spoon | Java AST/metamodel optimized for analysis and transformation | Moderate | Strong for Java analysis/transformation | **Defer unless Java-first** |  |
| Clang AST | Compiler-grade C/C++ AST and matching/query tooling | Moderate for specialist MVP work | Strong for C/C++ enterprise | **Integrate only for C/C++-heavy repos** |  |
| Python `ast` | Lightweight abstract syntax trees in stdlib | Strong for simple Python MVP parsing | Moderate | **Integrate** for basic Python support |  |
| LibCST | Immutable CST plus metadata such as exact positions | Strong when formatting/positions matter | Moderate | **Integrate selectively** for Python evidence fidelity |  |

### Comparison matrix for visualization and layout

| Item | Best use | MVP fit | Main risk | Recommendation | Primary evidence |
|---|---|---|---|---|---|
| D3 hierarchy | Trees, indented outlines, treemaps, icicles, sunbursts | Strong | Requires custom interaction code | **Integrate** |  |
| Cytoscape.js | Interactive relation graphs with selection, events, and headless analysis | Strong | Needs discipline to avoid hairballs | **Integrate** for bounded neighborhood graphs |  |
| Graphviz | Deterministic static graph layout and export | Moderate | Weak interactivity | **Integrate as export/render backend**, not primary UI |  |
| Mermaid | Fast text-authored diagrams and docs integration | Moderate | Limited interaction and semantic depth | **Defer to export/docs** |  |
| PlantUML | Text-authored UML/class/component/sequence exports | Moderate | Better for documentation than exploration | **Defer to export/docs** |  |
| React Flow | Polished node-based UI component with built-in drag/zoom/minimap | Mixed | Strong workflow-builder visual connotation | **Avoid as primary code explorer**, acceptable for constrained inspection panels |  |
| ELK | Advanced automatic layouts, compound graphs, ports | Moderate | Layout engine only; adds complexity | **Defer until graph layouts need it** |  |
| Dagre | Client-side directed graph layout | Moderate | Simpler than ELK, less expressive | **Optional integrate** for small DAG layouts |  |
| Doxygen + Graphviz | Documentation-centric inheritance and associated graphs | Weak for MVP UI | Static docs mentality | **Defer** as inspiration/export only |  |

### Comparison matrix for products and reference systems

| Item | What it proves | Fit as dependency | What to copy | Recommendation | Primary evidence |
|---|---|---|---|---|---|
| SciTools Understand | Mature static code comprehension with repository, cross-reference, dependency, call, and control-flow views | Proprietary product, not a lightweight dependency | Rich reverse-engineering views; entity-level drilldown | **Inspiration / possible enterprise reference** |  |
| CodeScene | Hotspots, system maps, architectural coupling, review candidate identification | Not a dependency for core explorer | Hierarchical hotspot map; risk overlays; architecture lens | **Inspiration** |  |
| JetBrains IDE features | Strong bounded hierarchies, dependency analysis, focus-on-paths UX | Inspiration, not embedded dependency | Caller/callee hierarchy, neighborhood/path focus | **Copy UX patterns** |  |
| VS Code + LSP | Practical symbol navigation and inline peek workflow | Ecosystem/developer reference | Peek references/definition; symbol search; protocol-driven features | **Copy interaction patterns, integrate via protocol only** |  |
| Sourcegraph | Precise navigation, cross-repo code intelligence, SCIP-based serving | Too large as MVP dependency | Search + semantic navigation; code intelligence panel; citations direction | **Enterprise reference and optional later integration** |  |
| OpenGrok | Search and cross-reference engine | Possible later on-prem search component | Fast cross-reference and source-tree navigation | **Defer** |  |
| SonarQube / SonarCloud | Issue workflow, code metrics, security hotspots | Adjacent only | Issue triage and quality overlays | **Integrate findings only if needed; avoid as primary object explorer** |  |
| Sourcetrail | Offline visual source explorer concept | Official project archived | Graph + source split view; unfamiliar-code onboarding | **Inspiration only; avoid official dependency** |  |

## Product pattern analysis

The most transferable product patterns come from **JetBrains, Sourcegraph, Understand, CodeScene, and Sourcetrail**. JetBrains validates the value of **hierarchy-first, bounded exploration**: class/method/call hierarchies, dependency analysis, and “focus on paths between two nodes” are directly aligned with the prompt’s assumption that contextual views are more readable than whole-repo graphs. Cooperative Cockpit should copy the idea of toggling between caller/callee, parent/child, and focused-path views, and should avoid any interaction that makes users feel they have entered a generic diagram editor. 

Sourcegraph validates the value of **symbol identity plus evidence-backed navigation** at scale. Its most important lesson is architectural rather than visual: semantic navigation becomes materially better when navigation is driven by an index that stores symbol identity, package ownership, dependency version data, exact definition locations, and reference relationships. Cooperative Cockpit should copy the split between **text search breadth** and **precise semantic navigation depth**, while avoiding enterprise bloat in the MVP. 

SciTools Understand validates that developers will use **graphical reverse-engineering views** when those views answer concrete entity questions such as “what depends on this?”, “where is it referenced?”, and “what control paths exist here?”. It is a strong positive comparator for call graphs, dependency graphs, control-flow views, and code-linked entity inspectors, especially because it maintains a source-centric mental model rather than a workflow-canvas mental model. 

CodeScene validates the value of **risk overlays** and **hierarchical system maps**. Its hotspot maps, architectural component views, and change-coupling analysis are especially relevant for a later Cooperative Cockpit “review context” layer. Cooperative Cockpit should copy the idea that risk, ownership, and change-coupling are overlays on top of code objects rather than replacements for code-object navigation. It should avoid inheriting CodeScene’s primary dependence on historical VCS analytics as the initial wedge, because the prompt’s strongest wedge is evidence-linked code review, not hotspot mining alone. 

Sourcetrail remains the best **conceptual inspiration** for graph + source split view and unfamiliar-code onboarding, but the official project was archived by its original maintainers in 2021. That makes it useful as a pattern reference, not as a product dependency. The existence of community forks is relevant but weaker evidence than the official archive state, so it should be treated as a verification backlog item rather than a recommendation base. 

OpenGrok and SonarQube are best treated as **adjacent references** rather than product models. OpenGrok is search and cross-reference oriented. SonarQube is issue and metrics oriented, with explicit issue-review workflow and measures tabs. Both help define boundaries: Cooperative Cockpit should not become “just another code search engine” or “just another issue dashboard.” 

## Recommended model and visualization patterns

### Recommended code-object model

The repository already has a strong artifact model for Project, Context Node, Spec Draft, Review Run, Finding, Decision, Evidence, Work Packet, and derived Handoff Packet. The cleanest extension is **not** to replace that model, but to add a **code-object substrate** that Review Run, Findings, Decisions, and Evidence can reference. The substrate should be normalized enough to support both local file-local parsing and later enterprise indexing. 

**Recommended `CodeObject` fields**

| Field | Purpose |
|---|---|
| `id` | Stable internal identifier |
| `kind` | repo, folder, package, file, module, class, interface, type, function, method, block, statement, test, config |
| `name` | Display name |
| `qualified_name` | Fully qualified symbol path where possible |
| `language` | Source language |
| `repository` | Repo identifier |
| `path` | Repo-relative path |
| `start_line`, `end_line` | Primary evidence anchor |
| `start_col`, `end_col` | Optional precision anchor |
| `parent_id` | Hierarchy link |
| `signature` | Function/method/type signature where known |
| `doc_summary` | Short extracted or reviewer-authored description |
| `metrics` | Size, complexity, churn, coverage, risk |
| `evidence_refs` | Array of evidence IDs |
| `confidence` | Extraction confidence |
| `extraction_method` | tree-sitter, compiler API, LSP, SCIP, CodeQL, Joern, manual |
| `version_ref` | commit/revision if available |

**Recommended `RelationEdge` fields**

| Field | Purpose |
|---|---|
| `id` | Stable edge identifier |
| `source_object_id`, `target_object_id` | Endpoints |
| `relation_type` | See taxonomy below |
| `direction` | forward, reverse, bidirectional |
| `evidence_refs` | Exact supporting evidence |
| `confidence` | Extraction confidence |
| `extraction_method` | Parser/protocol/analysis source |
| `limitations` | Missing-build, best-effort, indexed-only, inferred |
| `attributes` | Optional payload such as import alias, read/write kind, call count |

**Recommended `ReviewFinding` fields**

| Field | Purpose |
|---|---|
| `finding_id` | Stable finding identifier |
| `object_id` | Primary code object under review |
| `edge_id` | Optional relation target |
| `finding_type` | correctness, maintainability, security, test-gap, boundary, complexity, duplication, unclear-intent |
| `severity` | info, low, medium, high, critical |
| `claim` | Human-readable finding |
| `rationale` | Review justification |
| `evidence_refs` | Required supporting evidence |
| `source_agent_or_reviewer` | Provenance |
| `status` | proposed, accepted, disputed, resolved, deferred |
| `recommended_action` | Next review action |
| `confidence` | Claim confidence |

**Recommended `AgentAnnotation` fields**

| Field | Purpose |
|---|---|
| `annotation_id` | Stable annotation ID |
| `target_type` | object or edge |
| `target_id` | Object or edge ID |
| `agent_id` | Agent provenance |
| `annotation_type` | summary, question, risk, hypothesis, counterexample, explanation |
| `claim` | Annotation text |
| `evidence_refs` | Required support |
| `confidence` | Estimated confidence |
| `review_status` | unreviewed, accepted, rejected, needs-human-check |

**Recommended `EvidenceRef` fields**

| Field | Purpose |
|---|---|
| `evidence_id` | Stable evidence ID |
| `source_type` | source_line, ast_node, cst_node, symbol_index, commit, test_output, doc, manual_note |
| `file_path` | File anchor |
| `start_line`, `end_line` | Line anchor |
| `start_col`, `end_col` | Column anchor |
| `commit_hash` | Revision anchor if available |
| `symbol_identity` | Symbol ID or qualified name |
| `snippet_hash` | Deduplicate and integrity-check snippets |
| `retrieved_at` | Audit trail |
| `tool_source` | tree-sitter, roslyn, tsc, lsp, scip, codeql, joern, manual |
| `source_link` | Optional UI deep link |

This schema is consistent with existing product canon, because it keeps the current human-governance objects intact while giving them a stable, shared code substrate. It is also consistent with LSP-style ranges, SCIP symbol locations, and LibCST position-aware metadata. 

### Recommended relationship taxonomy

The normalized relationship taxonomy should be a **superset**, because different extractors populate different slices. The minimum practical taxonomy is:

| Group | Relations |
|---|---|
| Structural | `contains`, `defines`, `declares`, `parent_of`, `child_of` |
| Name and usage | `references`, `referenced_by`, `resolves_to`, `aliases` |
| Call and runtime intent | `calls`, `called_by`, `instantiates`, `throws`, `catches`, `emits`, `handles` |
| Type and inheritance | `extends`, `implements`, `overrides`, `specializes`, `typed_as` |
| Module and packaging | `imports`, `exports`, `depends_on`, `included_by`, `configures` |
| State interaction | `reads`, `writes`, `mutates` |
| Quality and review context | `tests`, `tested_by`, `duplicates_logic_with`, `violates_boundary`, `owned_by`, `changed_with`, `derived_from_evidence` |

In practice, **Tree-sitter and compiler APIs** are best for `contains`, `defines`, and some `imports`; **LSP** is best for `documentSymbol`, `references`, `definitions`, `implementations`, call hierarchy, and type hierarchy; **SCIP** is best for stable symbol and cross-repo navigation; **CodeQL/Joern** are best for deeper flow-oriented edges. 

### Visualization pattern recommendations

| View | Purpose | Required data | Recommended approach | Recommended library | MVP suitability | Main risk |
|---|---|---|---|---|---|---|
| Code object tree | Repo → folder → file → symbol hierarchy | `CodeObject` hierarchy | Indented tree / collapsible tree | D3 hierarchy | High | Too dense if expanded indiscriminately |
| Symbol outline | File-local symbol navigation | File-local symbols | Sidebar outline | Plain DOM or D3 | High | Limited cross-file context |
| Selected-object neighborhood graph | Show immediate semantic context around one object | Object + bounded edges | Centered neighborhood graph | Cytoscape.js | High | Hairballs if radius grows too far |
| Call hierarchy | Caller/callee exploration | `calls` edges | Expandable tree or radial tree | D3 hierarchy or Cytoscape.js | High | False confidence when extraction is partial |
| Import/dependency graph | Module/package dependency inspection | `imports`, `depends_on` | Layered directed graph | Cytoscape.js + Dagre/ELK | Medium | Becomes unreadable at repo scale |
| Class/type hierarchy | Supertypes/subtypes, overrides | `extends`, `implements`, `overrides` | Expandable type tree | D3 hierarchy | High | Inconsistent language coverage |
| Function/block control-flow view | Explain local logic | Basic block / CFG nodes | Mini CFG panel | Cytoscape.js or Graphviz export | Medium | Too technical for non-specialists |
| Data-flow/security view | Taint, flows, source-to-sink reasoning | Flow graph | Stepwise path view, not full graph | Cytoscape.js | Low for MVP | Requires deep analysis backend |
| Treemap/hotspot view | Size/churn/risk overview | hierarchy + metrics | Treemap / circlepack | D3 treemap | Medium | Can look like dashboard if overdone |
| Evidence inspector | Show exact backing code and source lines | `EvidenceRef` | Split pane with line-linked snippets | Plain DOM + code viewer | Very high | Weak if evidence is approximate |
| Review finding overlay | Attach findings to objects and lines | findings + object IDs + evidence | Chips, badges, side panels | Plain DOM + source gutters | Very high | Mixing facts with recommendations |
| AI annotation layer | Separate agent commentary from facts | annotations + review state | Collapsible overlay panel | Plain DOM | Very high | Claim pollution if status is unclear |
| Architecture boundary map | Package/component boundaries and violations | grouped objects + dependency edges | Layered graph or matrix | Cytoscape.js or Graphviz export | Medium | Over-abstracting before symbol-level grounding |

These recommendations reflect the fact that D3 hierarchy is specialized for hierarchical structures, Cytoscape.js is specialized for interactive graph relations, Graphviz is specialized for reproducible layout, and mature tools like JetBrains and CodeScene already converge on bounded hierarchies, neighborhood views, and drill-down maps rather than a single “everything graph.” 

## MVP and enterprise architecture

### MVP architecture recommendation

The candidate path in the prompt is directionally correct, but it needs one crucial adjustment because of current repository guardrails: it should be expressed as an **approval-gated future implementation path**, not as an immediate in-repo implementation plan. Today’s repo canon forbids new dependencies and any move toward backend/runtime semantics without Point lock. Within that constraint, the current repo should remain a **static mock-data product surface**. The build recommendation below is therefore the **best next MVP after approval**, while current in-repo work should remain object-model and UX specification work. 

The strongest approved-next MVP stack is:

| Layer | Recommendation | Why |
|---|---|---|
| Extraction | Tree-sitter for hierarchy and block structure; language-native APIs where first-party support is easy | Fast, local, error-tolerant, and enough for structural comprehension MVPs |
| Semantic enrichment | LSP where available for document symbols, refs, defs, implementations, call/type hierarchy | Reuses mature ecosystem without requiring persistent backend |
| Storage | JSON-first object graph; SQLite only if local caching becomes necessary | Matches static/offline philosophy and avoids premature infra |
| Rendering | D3 hierarchy for tree/treemap views; Cytoscape.js for bounded relation graphs | Best tool split for hierarchy plus relation exploration |
| Review layer | `ReviewFinding`, `AgentAnnotation`, `EvidenceRef` attached to stable object IDs | Preserves human/AI shared context |
| Export | Optional Graphviz/Mermaid/PlantUML snapshot export | Good for reports and docs without driving UI design |

This stack is consistent with the MVP goal because Tree-sitter is incremental and robust, LSP gives protocol-standard semantic navigation where servers support it, D3 hierarchy is purpose-built for hierarchical visualizations, and Cytoscape.js is a mature interactive graph library. 

What should be **deferred** is equally important. **Kythe** should be deferred because it is most valuable when you need a larger interchange/storage system and custom serving pipeline. **SCIP/Sourcegraph-style persistent index infrastructure** should be deferred until you need cross-repo navigation, large-repo incremental indexing, or team-scale search. **CodeQL** and **Joern** should be deferred unless the near-term wedge includes security review, taint analysis, or advanced variant mining. **Deep data flow**, **runtime tracing**, and any **backend/API/auth/database/deployment** work should remain out of scope for the current product phase. 

### Future enterprise architecture

The likely long-term architecture is **SCIP-first persisted indexing plus a custom governed review layer**. In that architecture, language-specific indexers produce **SCIP indexes** and symbol metadata for definitions, references, implementations, and cross-repo symbol identity; a serving layer resolves symbol navigation and neighborhood queries; a separate annotation/review store holds findings, decisions, evidence manifests, AI trails, and audit metadata; and the UI renders bounded views linked to exact evidence spans. Sourcegraph’s current use of SCIP for precise and cross-repo navigation, together with SCIP’s open-governance direction, makes it the best evidence-backed long-term protocol direction in this list. 

A future enterprise stack should distinguish **facts from overlays**. Facts are objects, edges, symbols, ranges, commits, and index artifacts. Overlays are review findings, risk scores, ownership, change coupling, AI annotations, and decisions. This separation is what allows multiple AI agents and humans to annotate the same code substrate without corrupting semantic truth. Sourcegraph’s precise index model, CodeScene’s overlay-style hotspots and architectural change coupling, and SonarQube’s issue workflow all point toward the value of separating analysis layers from base code navigation. 

A plausible enterprise target architecture is:

| Capability | Recommended direction |
|---|---|
| Persistent indexing | SCIP-backed per-language indexers with incremental upload |
| Multi-language support | Language-native indexers behind normalized schema |
| Multi-repo support | Symbol ID + package/version aware cross-repo resolution |
| Incremental updates | CI/indexing pipeline plus background refresh |
| Team annotations | Separate annotation store keyed by `CodeObject` / `RelationEdge` IDs |
| Permission-aware evidence access | Respect repo/provider authorization at snippet and file fetch time |
| AI review trails | Immutable prompt/claim/evidence/reviewer-status records |
| Auditability | Versioned evidence manifests and decision history |
| GitHub/GitLab/Bitbucket integration | Connector layer only in enterprise phase |
| IDE integration | Deep links into VS Code / JetBrains / browser code views |
| Security/privacy boundaries | On-prem indexing for private code; avoid external code shipment by default |

### Build, integrate, defer, avoid

| Item | Recommendation | Rationale | Evidence strength | Suggested milestone |
|---|---|---|---|---|
| Normalized `CodeObject` / `RelationEdge` / `EvidenceRef` model | **Build** | This is the missing product-specific layer | High | MVP design now |
| Evidence-linked finding and annotation schema | **Build** | Core wedge is review with traceability | High | MVP design now |
| Tree-sitter structural extraction | **Integrate** | Best lightweight multi-language parser base | Strong | Approved-next MVP |
| Language-specific compiler APIs | **Integrate selectively** | Highest-fidelity per-language fallback | Strong | Language-by-language |
| LSP feature enrichment | **Integrate** | Strong semantic navigation without persistent backend | Strong | Approved-next MVP |
| D3 hierarchy | **Integrate** | Best fit for trees/treemaps/outlines | Strong | Approved-next MVP |
| Cytoscape.js | **Integrate** | Best fit for bounded semantic graphs | Strong | Approved-next MVP |
| Graphviz/Mermaid/PlantUML export | **Integrate later** | Useful for reports, not primary UI | Strong | Post-MVP |
| SCIP persistent indexing | **Defer** | Best long-term enterprise path, too heavy for MVP | Strong | Enterprise phase |
| Kythe | **Defer** | Powerful but more complex than needed | Strong | Enterprise exploration only |
| CodeQL | **Defer** | Great for security review, not required for comprehension MVP | Strong | Security phase |
| Joern / CPG backend | **Defer** | Valuable for taint/security, too heavy for initial wedge | Strong | Security phase |
| React Flow as primary renderer | **Avoid** | Wrong visual semantics for anti-workflow-builder boundary | Strong | Avoid |
| Whole-repo unconstrained graph | **Avoid** | High hairball risk and weak review value | Strong | Avoid |
| Sourcetrail official dependency | **Avoid** | Official project archived | Strong | Avoid |
| Backend/API/auth/database in current repo phase | **Avoid for now** | Current canon forbids it | Strong | Avoid until Point lock |

### Anti-patterns and risks

| Risk | Why it matters | Mitigation |
|---|---|---|
| Graph hairball problem | Whole-repo graphs hide answers instead of revealing them | Default to selected-object bounded radius, path focus, and hierarchy drill-down |
| Workflow-builder confusion | React Flow–style visuals can visually imply orchestration rather than code review | Keep nodes as code objects, findings, and evidence; avoid process-step affordances |
| Overbuilding analysis too early | Deep semantic backends can dominate schedule before proving product value | Launch with structure + evidence + bounded relations first |
| Single-parser lock-in | One parser will not cover all languages or semantic needs | Use normalized schema with extractor provenance |
| AI summaries without exact evidence | Breaks trust and governance | Require `EvidenceRef` on every AI-generated claim |
| Mixing facts, findings, recommendations, and decisions | Destroys auditability | Keep separate tables and explicit statuses |
| Large-repo performance collapse | Naive client-side graphing will fail on real repos | Bound queries, paginate edges, and cache precomputed neighborhoods |
| Stale indexes | Review conclusions drift from code reality | Version every evidence ref by commit/revision |
| Weak language-server support | LSP features vary by server and language | Treat LSP as enrichment, not sole source of truth |
| License or maintenance surprises | Archived or commercial constraints can block adoption | Prefer current official docs and approval-gated dependency decisions |

## Evidence registers and final recommendation

### Prototype experiments

| Experiment | Goal | Input | Success criteria | Failure signal | Decision informed |
|---|---|---|---|---|---|
| TypeScript structure pilot | Validate low-cost extraction for one representative TS repo | Small-to-medium TS repo | Extract repo/file/class/function/block hierarchy with stable IDs and line spans | Missing or unstable hierarchy IDs | Whether Tree-sitter + TS API is enough for TS MVP |
| Python structure pilot | Compare Python `ast` vs LibCST for evidence fidelity | Representative Python repo | Same hierarchy plus accurate line/column spans and preserved source mapping | Inaccurate evidence refs or poor block extraction | Whether Python needs LibCST instead of stdlib `ast` |
| LSP enrichment pilot | Measure incremental value of semantic enrichment | One repo with strong language-server support | Successful object-to-def/ref/refs/call/type links for selected symbols | Too much server variability or setup burden | Whether LSP should be MVP default or optional add-on |
| Bounded graph readability test | Validate neighborhood graph UX | 20 selected functions/classes from one repo | Reviewers can answer “what calls this?”, “what depends on this?”, “what evidence supports this?” quickly | Users ask for “show everything” because local view is insufficient or graph is unreadable | Radius defaults, layout choice, graph controls |
| Evidence-linked AI review trial | Prove traceable annotation workflow | 10 sample objects with snippets | Every AI claim includes exact evidence refs and survives human spot-check | Claims cannot be traced or evidence is ambiguous | Whether evidence-first AI layer is product wedge |

### Claim register

| Claim ID | Claim | Topic | Support status | Confidence | Risk if wrong | Primary source |
|---|---|---|---|---|---|---|
| C01 | Tree-sitter is an incremental parsing library that builds concrete syntax trees and updates them efficiently during editing | Parsing | Supported | High | Medium |  |
| C02 | LSP 3.17 standardizes document symbols, workspace symbols, definitions, implementations, references, call hierarchy, type hierarchy, folding ranges, and semantic tokens | Protocol | Supported | High | Low |  |
| C03 | LSIF is a persisted workspace dump intended to answer LSP requests without running the language server | Code intelligence index | Supported | High | Low |  |
| C04 | SCIP is a language-agnostic indexing protocol used for code navigation such as definitions and references | Code intelligence index | Supported | High | Low |  |
| C05 | Sourcegraph uses SCIP for precise code navigation and cross-repository symbol resolution | Enterprise indexing | Supported | High | Medium |  |
| C06 | Kythe is a language-agnostic interchange/storage mechanism for source-code information and expects separate serving/index layers | Interchange architecture | Supported | High | Medium |  |
| C07 | CodeQL is a query language and toolchain for code analysis designed for vulnerability and variant discovery | Static analysis | Supported | High | Medium |  |
| C08 | Joern generates code property graphs and supports taint analysis and query-based analysis across multiple languages | Static analysis | Supported | High | Medium |  |
| C09 | A code property graph combines AST, CFG, and program dependence information into one graph representation | CPG | Supported | High | Low |  |
| C10 | Doxygen uses Graphviz `dot` to generate more advanced diagrams and graphs beyond built-in inheritance diagrams | Docs and diagrams | Supported | High | Low |  |
| C11 | Cytoscape.js is a mature interactive graph library suitable for graph analysis and visualization in the browser | Visualization | Supported | High | Low |  |
| C12 | D3 hierarchy is specialized for hierarchical visualizations such as trees, treemaps, icicles, and sunbursts | Visualization | Supported | High | Low |  |
| C13 | React Flow is a node-based UI library with strong diagram-editor affordances and MIT licensing | Visualization UX risk | Supported | High | Medium |  |
| C14 | SciTools Understand is a commercial static-analysis/code-comprehension tool with cross-reference, graph, and control-flow capabilities | Product reference | Supported | High | Medium |  |
| C15 | CodeScene uses interactive hierarchical hotspot/system maps and architectural change-coupling analyses | Product reference | Supported | High | Medium |  |
| C16 | JetBrains IDEs emphasize bounded hierarchy, dependency analysis, and focused path exploration | Product pattern | Supported | High | Medium |  |
| C17 | Sourcetrail’s official repository was archived by its original maintainers in 2021 | Maintenance status | Supported | High | Medium |  |
| C18 | The current Cooperative Cockpit repo is static-only, eight-page, no-backend, no-new-dependencies without Point lock | Repo constraints | Supported | High | High |  |

### Source register

| Source ID | Source | Organization | Type | Date signal | Credibility | Relevance | Notes |
|---|---|---|---|---|---|---|---|
| S01 | Tree-sitter introduction | Tree-sitter | Official docs | Current site | High | High | Core parsing evidence  |
| S02 | Tree-sitter GitHub repo | tree-sitter | Official repo | Current | High | High | MIT and project summary  |
| S03 | LSP 3.17 specification | Microsoft | Official spec | Current spec page | High | High | Protocol truth source  |
| S04 | SCIP landing page | SCIP project | Official docs | Current | High | High | Protocol overview  |
| S05 | SCIP GitHub repo | scip-code | Official repo | Current | High | High | Apache-2.0 and tooling  |
| S06 | LSIF spec 0.6.0 | Microsoft | Official spec | Current page | High | High | Older persisted format  |
| S07 | Kythe overview | Kythe / Google | Official docs | Current | High | High | Interchange architecture  |
| S08 | Kythe storage model | Kythe / Google | Official docs | Current | High | High | Storage vs serving distinction  |
| S09 | CodeQL overview | GitHub | Official docs | Current | High | High | Security analysis scope  |
| S10 | Joern overview and CPG spec | Joern | Official docs/spec | Current | High | High | Multi-language CPG evidence  |
| S11 | CPG IEEE paper | IEEE S&P | Peer-reviewed paper | 2014 | High | High | Foundational CPG claim  |
| S12 | Doxygen diagrams docs | Doxygen | Official docs | Current | High | Medium | Static docs graphs  |
| S13 | Graphviz docs | Graphviz | Official docs | Current | High | Medium | Layout/export reference  |
| S14 | Cytoscape.js docs and repo | Cytoscape.js | Official docs/repo | Current | High | High | Interactive graph renderer  |
| S15 | D3 hierarchy docs | D3 | Official docs | Current | High | High | Hierarchy renderer  |
| S16 | React Flow docs and repo | xyflow | Official docs/repo | 2026 current docs | High | Medium | Useful but semantically risky for this product  |
| S17 | ELK docs | Eclipse | Official docs | Current | High | Medium | Layout engine reference  |
| S18 | Dagre repo | dagrejs | Official repo | Current | High | Medium | Client-side DAG layout  |
| S19 | PlantUML docs/repo | PlantUML | Official docs/repo | 2026 changes | High | Medium | Diagram export reference  |
| S20 | TypeScript Compiler API wiki | Microsoft TypeScript | Official wiki | 2023 edit date | High | High | TS extraction reference  |
| S21 | Python `ast` docs | Python | Official docs | 3.14.5 | High | High | Python AST reference  |
| S22 | LibCST metadata docs | LibCST | Official docs | Current | High | High | Exact position metadata  |
| S23 | Roslyn syntax/semantic docs | Microsoft | Official docs | Current pages | High | High | .NET compiler platform reference  |
| S24 | JavaParser and Spoon docs | JavaParser / Inria | Official docs/repos | Current | High | Medium | Java analysis options  |
| S25 | Clang AST docs | LLVM | Official docs | Current | High | Medium | C/C++ AST reference  |
| S26 | Understand manual/API/support docs | SciTools | Official docs | 2024–2025 signals | High | High | Commercial product evidence  |
| S27 | CodeScene docs | CodeScene | Official docs | Current | High | High | Hotspots and architecture overlays  |
| S28 | JetBrains IDEA docs | JetBrains | Official docs | 2024–2026 | High | High | Bounded hierarchy/product pattern evidence  |
| S29 | VS Code docs/API | Microsoft | Official docs | Current | High | High | Reference navigation patterns  |
| S30 | Sourcegraph docs and SCIP blog/posts | Sourcegraph | Official docs/blog | 2022–2026 | High | High | Enterprise direction and SCIP usage  |
| S31 | OpenGrok docs | Oracle / OpenGrok | Official docs | Current | High | Medium | Search/cross-reference comparator  |
| S32 | SonarQube docs | SonarSource | Official docs | 2026 doc version pages | High | Medium | Issue/metrics comparator  |
| S33 | Cooperative Cockpit product canon files | CharnritK/cooperative-cockpit | Official repo docs | 2026 repo state | High | Very high | Scope guardrails and MVP object model  |

### Gap backlog

| Gap ID | Gap | Severity | Preferred source type | Follow-up action |
|---|---|---|---|---|
| G01 | Exact current license/commercial terms for every open-source candidate were not normalized in one unified table | Medium | Official license files | Verify before implementation approval |
| G02 | Current maturity and coverage of each individual SCIP indexer by language was not exhaustively benchmarked | High | Official indexer docs/repos | Run language-by-language pilot before enterprise commitment |
| G03 | Community Sourcetrail forks may be active, but official support posture remains archived | Medium | Official fork docs/releases | Verify if any fork is strategically relevant |
| G04 | LSP feature consistency across language servers was not experimentally measured for target languages/repos | High | Practical tests | Run pilot against representative TS/Python/C# repos |
| G05 | Large-repo browser performance thresholds for Cytoscape.js were not benchmarked in this report | Medium | Prototype measurements | Test bounded graph sizes and fallback rendering |
| G06 | Evidence model integration with future authz/code-host permissions is architectural only, not implementation-validated | Medium | Enterprise architecture docs and connector tests | Validate in enterprise phase |

### Final recommendation

The **best MVP stack** is a **custom code-object/evidence/review layer** over lightweight extraction primitives: Tree-sitter or language-native parsers for hierarchy, optional LSP enrichment for references/definitions/call/type relationships, JSON-first storage, D3 hierarchy for trees and treemaps, Cytoscape.js for selected-object neighborhood graphs, and a strict evidence model that attaches every finding and AI annotation to exact code spans. This is the option with the best balance of maturity, usability, bounded complexity, and fit to the current product wedge. 

The **strongest alternative stack** is a more language-opinionated path: TypeScript Compiler API for TS/JS-first repos, Roslyn for C#, Python `ast`/LibCST for Python, with the same UI and evidence model. This alternative is stronger when your early repository set is narrow and known, and weaker if you need immediate polyglot breadth. 

The **long-term architecture direction** should be **SCIP-first enterprise indexing plus a separate reviewed-annotation layer**, not a monolithic graph database from day one. Use a persisted code-intelligence substrate when you truly need precise cross-repo navigation, large-scale indexing, and enterprise serving. Add CodeQL or Joern only when security/static-analysis review becomes a first-class product mode. 

The **top build decisions** are: build the normalized code-object schema; build the evidence manifest model; build findings/annotations as overlays rather than facts; build bounded navigation views instead of whole-repo canvases; build line-linked claim traceability into the product contract. The **top integration decisions** are: integrate Tree-sitter or language-native parsers; integrate LSP as enrichment; integrate D3 hierarchy; integrate Cytoscape.js; integrate static export paths only as secondary outputs. The **top deferred decisions** are: SCIP persistent indexing, Kythe, CodeQL, Joern, and cross-repo serving. The **top avoid decisions** are: React Flow as the primary mental model, workflow-builder UI semantics, unofficial archived dependencies, whole-repo free-form graphs, and any AI claim without exact evidence. 

The **top risks** are graph readability, overbuilding static analysis before proving review value, language-support inconsistency, stale evidence, and repository guardrail violations. The confidence level for the hybrid recommendation is **high**. The highest-priority validations before implementation are: extraction quality on one representative TypeScript repo and one representative Python repo, LSP enrichment coverage on those repos, bounded-graph readability with real symbols, and the operational strictness of evidence-linked AI annotations. 

### Open questions and limitations

This report is strongest on **architecture direction and tool fit**, and intentionally lighter on exhaustive benchmark data. It does not experimentally measure extraction accuracy, graph rendering performance, or language-server variance on your target repositories. It also does not normalize every license and operational nuance for every candidate into implementation-ready procurement guidance. Those items should be handled in the prototype phase before any Point-lock implementation decision.
