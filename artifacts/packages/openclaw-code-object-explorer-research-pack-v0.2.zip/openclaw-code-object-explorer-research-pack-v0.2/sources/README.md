# Source Files

This folder contains sanitized source inputs used by the v0.2 synthesis.

## Files

- `SOURCE_00_CHATGPT_DEEP_RESEARCH.md` — primary source.
- `SOURCE_01_GEMINI_COMPARATOR.md` — secondary comparator.
- `SOURCE_02_WEN_COMPARATOR.md` — secondary comparator.

## Sanitization

Transient chat/web citation markers were removed because they are not repo-persistable. The canonical source mapping lives in:

- `../OFFICIAL_SOURCE_REGISTER.md`
- `../CLAIM_TO_SOURCE_MATRIX.md`
- `../EVIDENCE_STANDARD.md`

Comparator reports are not treated as authoritative source evidence unless corroborated by the primary report or official sources.
