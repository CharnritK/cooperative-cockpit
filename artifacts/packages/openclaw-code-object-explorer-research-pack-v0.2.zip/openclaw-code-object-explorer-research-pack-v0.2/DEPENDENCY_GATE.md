# Dependency Gate

Status: v0.2 review-gate artifact.

No dependency listed here is approved merely by appearing in this package. Dependencies require Point-lock review before implementation.

## Candidate dependency gates

| dependency | intended use | phase | approval status | required review |
|---|---|---|---|---|
| Tree-sitter / grammars | Local structural parsing | P1 | Not approved | License, bundle size, WASM feasibility, grammar quality |
| TypeScript Compiler API | TS semantic fallback | P1 | Not approved | License, Node/browser feasibility, bundle size |
| Babel parser | JS/TS AST fallback | P1 | Not approved | License, syntax coverage, maintenance |
| Python ast / LibCST | Python extraction | P1 | Not approved | Runtime feasibility, packaging approach |
| LSP server packages | Semantic enrichment | P2 | Not approved | Local process policy, licenses, install UX |
| D3 hierarchy | Object tree/treemap | P1/P2 | Not approved | License, bundle size, static MVP compatibility |
| Cytoscape.js | Bounded relation graph | P1/P2 | Not approved | License, performance, accessibility |
| ELK / elkjs | Layered graph layout | P1/P2 | Not approved | License, bundle size, layout performance |
| Graphviz | Static export | P2+ | Not approved | Packaging, wasm/native dependency risk |
| Mermaid | Static export | P2+ | Not approved | Security, rendering sanitization |
| PlantUML | Static export | P2+ | Not approved | Java/server requirement risk |
| React Flow | Node canvas | Avoid for core | Not approved | Workflow-builder metaphor risk |
| SCIP/Kythe | Enterprise indexing | P3 | Not approved | Backend, CI, storage, auth, ops |
| CodeQL/Joern | Deep security analysis | P3 | Not approved | Compute, license, security review, ops |

## Dependency review gate

| gate_id | reviewer | review_scope | pass_condition | fallback |
|---|---|---|---|---|
| RG-DEP-001 | Point + technical reviewer | Any new package, binary, runtime, or external tool | Dependency has clear purpose, license approval, no guardrail violation, and validation plan | Use static mock data or defer |
| RG-DEP-002 | Security/privacy reviewer | Any parser/indexer reading source code | Local-only handling, no external code shipment, secret redaction strategy | Block ingestion and use fixtures |
