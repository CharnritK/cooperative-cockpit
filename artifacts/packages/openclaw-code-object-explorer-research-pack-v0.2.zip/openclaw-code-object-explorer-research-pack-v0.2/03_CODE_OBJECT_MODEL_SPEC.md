# 03 — Code Object Model Spec

## Design principles

1. Parser-neutral.
2. Stable IDs.
3. Exact evidence refs.
4. Separation of facts, findings, annotations, and decisions.
5. Extraction provenance and confidence on every edge.

## TypeScript-like interfaces

```ts
export type CodeObjectKind =
  | "repository" | "folder" | "package" | "file" | "module"
  | "class" | "interface" | "component" | "function" | "method"
  | "block" | "statement" | "variable" | "test";

export interface CodeObject {
  id: string;
  kind: CodeObjectKind;
  name: string;
  qualified_name?: string;
  language?: string;
  repository: string;
  path?: string;
  start_line?: number;
  end_line?: number;
  parent_id?: string;
  signature?: string;
  doc_summary?: string;
  metrics?: Record<string, number | string>;
  evidence_refs: string[];
  confidence: number;
  extraction_method: string;
  limitations?: string[];
}

export interface RelationEdge {
  id: string;
  source_object_id: string;
  target_object_id: string;
  relation_type: string;
  direction: "forward" | "reverse" | "bidirectional";
  evidence_refs: string[];
  confidence: number;
  extraction_method: string;
  limitations?: string[];
}

export interface EvidenceRef {
  evidence_id: string;
  source_type: "file" | "snippet" | "commit" | "analysis_artifact";
  file_path: string;
  start_line: number;
  end_line: number;
  commit_hash?: string;
  source_url?: string;
  snippet_hash: string;
  retrieved_at: string;
}

export interface ReviewFinding {
  finding_id: string;
  object_id?: string;
  edge_id?: string;
  finding_type: string;
  severity: "info" | "low" | "medium" | "high" | "critical";
  claim: string;
  rationale: string;
  evidence_refs: string[];
  source_agent_or_reviewer: string;
  status: "draft" | "open" | "accepted" | "rejected" | "resolved";
  recommended_action?: string;
  confidence: number;
}

export interface AgentAnnotation {
  annotation_id: string;
  object_id?: string;
  edge_id?: string;
  agent_id: string;
  annotation_type: "summary" | "risk" | "question" | "recommendation" | "hypothesis";
  claim: string;
  evidence_refs: string[];
  confidence: number;
  review_status: "unreviewed" | "human_accepted" | "human_rejected" | "needs_more_evidence";
}
```

## Example: TypeScript function

```json
{
  "id": "codeobj:repo:src/user/auth.ts#L22-L55",
  "kind": "function",
  "name": "validateSession",
  "qualified_name": "src.user.auth.validateSession",
  "language": "TypeScript",
  "repository": "local-sample-repo",
  "path": "src/user/auth.ts",
  "start_line": 22,
  "end_line": 55,
  "parent_id": "codeobj:repo:src/user/auth.ts",
  "signature": "validateSession(token: string): Promise<Session>",
  "doc_summary": "Validates a session token and returns session data.",
  "metrics": { "lines": 34 },
  "evidence_refs": ["ev:src/user/auth.ts#L22-L55"],
  "confidence": 0.9,
  "extraction_method": "fixture_or_parser"
}
```

## Example: Python method

```json
{
  "id": "codeobj:repo:services/payments.py#L80-L132",
  "kind": "method",
  "name": "charge",
  "qualified_name": "PaymentService.charge",
  "language": "Python",
  "repository": "local-sample-repo",
  "path": "services/payments.py",
  "start_line": 80,
  "end_line": 132,
  "parent_id": "codeobj:repo:services/payments.py#PaymentService",
  "signature": "charge(self, request)",
  "evidence_refs": ["ev:services/payments.py#L80-L132"],
  "confidence": 0.85,
  "extraction_method": "fixture_or_parser"
}
```
