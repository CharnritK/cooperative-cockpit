# Official Source Register

Status: Evidence map for v0.2.  
Generated: 2026-06-01.  
Live web verification: **not performed in this package generation run**. Web access was not used. The URLs below are official source targets carried from the ChatGPT deep research result and known public documentation locations. Any claim that depends on current maintenance, version, license, or exact capability must be verified before implementation.

## Source hierarchy

1. Official documentation, specifications, protocol docs, API docs.
2. Official repositories, license files, release notes, maintainer statements.
3. Peer-reviewed or canonical technical papers.
4. Product documentation from mature commercial tools.
5. Comparator reports included in `sources/`, treated as secondary.

## Official source coverage

| source_id | source_title | organization | source_type | source_url | used_for | credibility | notes |
|---|---|---|---|---|---|---|---|
| OS-001 | Tree-sitter documentation | Tree-sitter | Official docs | https://tree-sitter.github.io/tree-sitter/ | Parsing/CST/incremental parsing | High | Primary official source candidate. Live verification not performed in this packaging run. |
| OS-002 | Tree-sitter GitHub repository | tree-sitter | Official repository | https://github.com/tree-sitter/tree-sitter | License, maintenance, bindings | High | Verify release/license before dependency approval. |
| OS-003 | Language Server Protocol 3.17 specification | Microsoft | Official specification | https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/ | LSP methods and capabilities | High | Primary protocol source. |
| OS-004 | SCIP GitHub repository | Sourcegraph / scip-code | Official repository | https://github.com/sourcegraph/scip | SCIP protocol, schema, license | High | Verify current governance and indexer ecosystem. |
| OS-005 | SCIP protocol documentation | SCIP project | Official docs | https://github.com/sourcegraph/scip/blob/main/scip.proto | SCIP protobuf schema | High | Schema source; live verification needed before implementation. |
| OS-006 | LSIF 0.6 specification | Microsoft | Official specification | https://microsoft.github.io/language-server-protocol/specifications/lsif/0.6.0/specification/ | LSIF format | High | Use for historical/legacy comparison. |
| OS-007 | Kythe overview | Kythe / Google | Official docs | https://kythe.io/docs/ | Kythe architecture and cross-reference model | High | Verify current maintainer status before enterprise use. |
| OS-008 | Kythe schema documentation | Kythe / Google | Official docs | https://kythe.io/docs/schema/ | Kythe node/edge schema | High | Relevant to enterprise storage model. |
| OS-009 | CodeQL documentation | GitHub | Official docs | https://codeql.github.com/docs/ | Query language and analysis scope | High | Security/static analysis phase only. |
| OS-010 | CodeQL GitHub repository | GitHub | Official repository | https://github.com/github/codeql | License, query packs, languages | High | Verify license and supported languages. |
| OS-011 | Joern documentation | Joern | Official docs | https://joern.io/ | Code property graph, taint analysis | High | Security/static analysis phase only. |
| OS-012 | Joern GitHub repository | joernio | Official repository | https://github.com/joernio/joern | Maintenance, license, frontends | High | Verify before enterprise adoption. |
| OS-013 | Cytoscape.js documentation | Cytoscape.js | Official docs | https://js.cytoscape.org/ | Interactive graph rendering | High | Candidate renderer after dependency gate. |
| OS-014 | Cytoscape.js GitHub repository | Cytoscape.js | Official repository | https://github.com/cytoscape/cytoscape.js | License and maintenance | High | Verify license/maintenance before dependency gate. |
| OS-015 | D3 hierarchy documentation | D3 | Official docs | https://d3js.org/d3-hierarchy | Tree/treemap/hierarchy layouts | High | Candidate for object tree/hotspot view. |
| OS-016 | ELK documentation | Eclipse Layout Kernel | Official docs | https://www.eclipse.org/elk/ | Layered graph layout | High | Used through elkjs if approved. |
| OS-017 | elkjs GitHub repository | kieler | Official repository | https://github.com/kieler/elkjs | JavaScript layout engine | High | Verify bundle size and license. |
| OS-018 | Graphviz documentation | Graphviz | Official docs | https://graphviz.org/documentation/ | Static graph layout/export | High | Export path, not primary UI. |
| OS-019 | Mermaid documentation | Mermaid | Official docs | https://mermaid.js.org/ | Text-to-diagram export | High | Export path, not primary UI. |
| OS-020 | PlantUML documentation | PlantUML | Official docs | https://plantuml.com/ | Text-to-diagram export | High | Export path, not primary UI. |
| OS-021 | Sourcegraph code navigation docs | Sourcegraph | Official docs | https://sourcegraph.com/docs/code_navigation | Precise code navigation, SCIP use | Medium | URL may change; verify current docs. |
| OS-022 | Sourcegraph docs | Sourcegraph | Official docs | https://sourcegraph.com/docs | Enterprise code search/navigation | Medium | Enterprise comparator. |
| OS-023 | Sourcetrail GitHub repository | CoatiSoftware | Official repository | https://github.com/CoatiSoftware/Sourcetrail | Archived/reference project | Medium | Use only as UI inspiration; verify archived status. |
| OS-024 | CodeScene documentation | CodeScene | Official docs | https://docs.codescene.com/ | Hotspots and change coupling | Medium | Enterprise/product pattern comparator. |
| OS-025 | SciTools Understand documentation | SciTools | Official docs | https://documentation.scitools.com/ | Static analysis, graphing, metrics | Medium | Commercial tool comparator; verify access. |
| OS-026 | JetBrains IntelliJ IDEA documentation | JetBrains | Official docs | https://www.jetbrains.com/help/idea/ | IDE navigation and hierarchy patterns | Medium | Product pattern comparator. |
| OS-027 | Visual Studio Code editing evolved docs | Microsoft | Official docs | https://code.visualstudio.com/docs/editor/editingevolved | Go to definition, references, symbols | High | LSP ecosystem comparator. |
| OS-028 | VS Code language extension docs | Microsoft | Official docs | https://code.visualstudio.com/api/language-extensions/programmatic-language-features | LSP/programmatic language features | High | Editor integration comparator. |
| OS-029 | OpenGrok GitHub repository | Oracle / OpenGrok | Official repository | https://github.com/oracle/opengrok | Cross-reference/search comparator | Medium | Verify current status before use. |
| OS-030 | OpenGrok documentation | OpenGrok | Official docs | https://opengrok.github.io/OpenGrok/ | Search/cross-reference | Medium | Comparator only. |
| OS-031 | SonarQube Server documentation | SonarSource | Official docs | https://docs.sonarsource.com/sonarqube-server/latest/ | Issue workflow/quality gates | Medium | Issue/review comparator; not primary code-object UI. |
| OS-032 | SonarCloud documentation | SonarSource | Official docs | https://docs.sonarsource.com/sonarcloud/ | Cloud issue/quality analysis | Medium | Comparator; external service risks. |

## Local package sources

| source_id | source_title | source_type | source_url | role | support policy |
|---|---|---|---|---|---|
| SRC-000 | ChatGPT Deep Research Report | Primary uploaded report | sources/SOURCE_00_CHATGPT_DEEP_RESEARCH.md | Primary synthesis | May support recommendations when consistent with official-source mapping. |
| SRC-001 | Gemini Comparator Report | Secondary uploaded report | sources/SOURCE_01_GEMINI_COMPARATOR.md | Comparator | Use for wording, risks, alternate architecture ideas. Do not use alone as final rationale. |
| SRC-002 | Wen 3.7 Max Comparator Report | Secondary uploaded report | sources/SOURCE_02_WEN_COMPARATOR.md | Comparator | Use for enterprise/CPG ideas. Treat aggressive claims as Needs Verification. |

## Required follow-up before implementation

- Verify current license and maintenance status for every dependency.
- Verify bundle size and browser feasibility for every client-side library.
- Verify language support claims against official indexer/parser/server docs.
- Verify that no source URL has moved.
- Replace `[TO_BE_VERIFIED]` placeholders in the claim matrix after live source review.
