# 14 — Prompt for Next Codex Goal

Use this only after Point approves repo persistence.

```text
Objective:
Persist the OpenClaw code-object explorer research package v0.2 into the repository as a research artifact.

Repository:
CharnritK/cooperative-cockpit

Input package:
openclaw-code-object-explorer-research-pack-v0.2.zip
Unzipped folder:
openclaw-code-object-explorer-research-pack-v0.2/

Allowed paths:
- artifacts/deep-research/openclaw-code-object-explorer/
- artifacts/packages/
- artifact manifest file only if repo convention requires it
- status note only if Point explicitly authorizes it

Forbidden actions:
- Do not modify apps/static-mvp.
- Do not add dependencies.
- Do not add backend/API/database/auth/deployment/runtime behavior.
- Do not implement parser, LSP, visualization, AI, MCP, or connector features.
- Do not commit, push, open PR, or publish unless explicitly authorized by Point.
- Do not claim tests passed unless actually run.

Required work:
1. Copy the unzipped v0.2 folder into the approved deep-research path.
2. Copy the zip into artifacts/packages.
3. Compute SHA256 checksum.
4. Add or update manifest entry if required.
5. Run recommended validation: npm run validate.
6. Report exact files added and validation result.

Acceptance criteria:
- All package files are present.
- Manifest is valid JSON.
- No source or canonical doc contains transient chat citation markers.
- No implementation files are modified.
- Validation command is run or, if unavailable, failure is reported honestly.

Stop conditions:
- Missing package file.
- Validation failure that cannot be fixed within allowed paths.
- Need to modify code, schemas, scripts, or product canon.
- Any dependency/backend/runtime/connector requirement appears.

Final response:
- Summary of files added.
- SHA256 checksum.
- Validation command and output.
- Any unresolved issues.
```
