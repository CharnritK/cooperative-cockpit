# 09 — Prototype Experiments

## Experiment 1 — Static fixture explorer

| field | value |
|---|---|
| goal | Validate UI concept without dependencies |
| input | Hand-authored JSON fixtures |
| method | Render object tree, bounded graph, evidence inspector |
| success | User can answer “what is this object, how is it related, what evidence supports it?” |
| failure | Users ask for full canvas or cannot trace evidence |
| decision | Whether the product wedge is understandable |

## Experiment 2 — Parser extraction pilot

Point-lock required.

| field | value |
|---|---|
| goal | Test Tree-sitter/language parser extraction |
| input | Small TypeScript/Python sample repo |
| method | Extract CodeObjects and line spans |
| success | Stable IDs, accurate line ranges, acceptable performance |
| failure | Missing hierarchy, bad spans, slow parsing |
| decision | Whether parser integration is viable |

## Experiment 3 — LSP enrichment pilot

Point-lock required.

| field | value |
|---|---|
| goal | Measure value of semantic enrichment |
| input | Repo with strong language server support |
| method | Extract document symbols, references, definitions, call/type hierarchy |
| success | Edges attach to objects and evidence refs |
| failure | Server setup burden or inconsistent results |
| decision | Whether LSP is default or optional |

## Experiment 4 — Bounded graph readability test

| field | value |
|---|---|
| goal | Validate graph radius and layout |
| input | 20 selected objects |
| method | Ask reviewers to inspect relationships and evidence |
| success | Reviewers answer comprehension questions quickly |
| failure | Graph becomes unreadable or too sparse |
| decision | Default graph radius and controls |

## Experiment 5 — Evidence-linked AI annotation trial

Point-lock required if real AI is used.

| field | value |
|---|---|
| goal | Validate evidence-first AI claim workflow |
| input | Static annotation fixtures or reviewed AI output |
| method | Enforce EvidenceRef and human review status |
| success | Every claim has exact evidence and reviewer status |
| failure | Untraceable claims or hallucinated identifiers |
| decision | Whether AI annotation is a launch wedge |
