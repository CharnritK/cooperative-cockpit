# 04 — Relationship Taxonomy

## Taxonomy

| category | relation_type | MVP status | extraction source | confidence default |
|---|---|---|---|---|
| Structural | contains | P0 fixture / P1 parser | fixture, AST/CST | High |
| Structural | imports | P1 parser | AST/CST | Medium |
| Structural | exports | P1 parser | AST/CST | Medium |
| Structural | defines | P0 fixture / P1 parser / P2 LSP | fixture, AST/CST, LSP | Medium |
| Symbol/reference | references | P2 LSP | LSP | Medium |
| Symbol/reference | defined_by | P2 LSP | LSP | Medium |
| Call | calls | P2 LSP / future index | LSP, SCIP | Medium |
| Call | called_by | P2 LSP / future index | derived | Medium |
| Type | extends | P2 LSP / parser | LSP, AST/CST | Medium |
| Type | implements | P2 LSP / parser | LSP, AST/CST | Medium |
| Type | overrides | P2 LSP / future index | LSP, SCIP | Medium |
| State | reads | Future | data-flow/static analysis | Low |
| State | writes | Future | data-flow/static analysis | Low |
| State | mutates | Future | data-flow/static analysis | Low |
| Error/event | throws | Future | AST/static analysis | Low |
| Error/event | catches | Future | AST/static analysis | Low |
| Event/UI | emits | Future | framework-specific analysis | Low |
| Event/UI | handles | Future | framework-specific analysis | Low |
| Config | configures | Future | config parser/manual evidence | Low |
| Test/review | tests | Future | naming/test mapping | Low |
| Test/review | tested_by | Future | inverse of tests | Low |
| Dependency | depends_on | P1/P2 | imports/build metadata | Medium |
| Change | changed_with | Future | Git history | Low |
| Ownership | owned_by | Future | CODEOWNERS/Git metadata | Low |
| Boundary | violates_boundary | Future | rule engine/manual review | Low |
| Duplication | duplicates_logic_with | Future | analysis/AI with evidence | Low |
| Evidence | derives_from_evidence | P0 | EvidenceRef map | High |

## Edge requirements

Every edge must include:

- source object ID;
- target object ID;
- relation type;
- extraction method;
- evidence refs;
- confidence;
- limitations.

## MVP rule

P0 may use only fixture edges. P1 may add parser edges after approval. P2 may add LSP edges after approval. Enterprise may add index/static-analysis edges after approval.
