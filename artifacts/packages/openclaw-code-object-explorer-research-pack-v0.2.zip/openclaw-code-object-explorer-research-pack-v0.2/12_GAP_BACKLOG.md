# 12 — Gap Backlog

| gap_id | severity | description | preferred follow-up | owner suggestion | milestone |
|---|---|---|---|---|---|
| GAP-001 | High | Live official-source verification not performed in package generation | Web/source audit of OFFICIAL_SOURCE_REGISTER | Research reviewer | Before repo persistence if claims need public support |
| GAP-002 | High | Dependency licenses and current maintenance not verified | License/current-status audit | Technical reviewer | Before any dependency gate |
| GAP-003 | High | Static MVP vs local parser prototype boundary needs Point decision | Point lock | Point | Before P1 |
| GAP-004 | High | Local LSP bridge may violate static/runtime boundary | Architecture review | Point + technical reviewer | Before P2 |
| GAP-005 | Medium | Tree-sitter performance on target repo sizes unknown | Parser prototype | Developer/researcher | P1 |
| GAP-006 | Medium | LSP support varies by language server | LSP pilot | Developer/researcher | P2 |
| GAP-007 | Medium | UX readability of bounded graph not user-tested | Usability test | Product/design reviewer | P0/P1 |
| GAP-008 | Medium | Secret redaction for code snippets not specified | Security design | Security reviewer | Before real code ingestion |
| GAP-009 | Medium | Enterprise storage/index choice unresolved | Architecture spike | Technical lead | P3 |
| GAP-010 | Low | Mermaid/PlantUML/Graphviz export value unvalidated | Export prototype | Developer | Post-MVP |
