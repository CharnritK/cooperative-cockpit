# 07 — Enterprise Architecture Handoff

Status: future architecture only. Not implementation authorization.

## Enterprise goals

- Persistent multi-repo indexing.
- Multi-language semantic navigation.
- Permission-aware evidence access.
- Team annotations and audit trails.
- AI review trails with exact evidence.
- Optional security/static-analysis overlays.

## Target architecture

| layer | direction | notes |
|---|---|---|
| Indexing | SCIP-first | Per-language indexers in CI |
| Interchange/storage | Kythe-inspired mapping | Enterprise exploration only |
| Search/navigation | Sourcegraph-style service or internal equivalent | Requires backend/auth |
| Static analysis | CodeQL/Joern optional | Security phase only |
| Annotation store | Separate database | Keeps facts separate from overlays |
| Evidence service | Permission-aware file/snippet retrieval | Must respect repo permissions |
| IDE integration | VS Code / JetBrains links | After index backend exists |
| Agent integration | MCP or equivalent | Enterprise connector gate |

## Fact vs overlay separation

Facts:
- CodeObject
- RelationEdge
- EvidenceRef
- symbols
- ranges
- commits
- index artifacts

Overlays:
- ReviewFinding
- AgentAnnotation
- risk scores
- ownership
- change coupling
- decisions

## Required gates

| gate | reviewer | pass condition |
|---|---|---|
| Architecture gate | Point + technical lead | Backend scope, storage, auth, and indexing approved |
| Security/privacy gate | Security/privacy reviewer | Private code is protected and access-controlled |
| Dependency/license gate | Legal/technical reviewer | All tools/licenses approved |
| AI governance gate | Point + reviewer | AI claims audited and evidence-linked |

## Migration path

1. Preserve stable IDs in static/P1 outputs.
2. Add commit hashes and source URLs to EvidenceRef.
3. Export fixture graph in backend-ingestable format.
4. Add SCIP mapping only after enterprise approval.
5. Add team annotation store last.
