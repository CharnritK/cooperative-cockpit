# 00 — Executive Decision Memo

## Decision

Use a **hybrid strategy**.

Build the Cooperative Cockpit-specific object, evidence, finding, annotation, and bounded-review UI layer. Integrate mature parser, protocol, and visualization tools only after explicit gates. Defer persistent semantic indexing and deep static analysis until enterprise scope.

## Recommendation

| track | recommendation | status |
|---|---|---|
| Static mock explorer | Build as static UX/spec surface | Allowed only within current static guardrails |
| Local parser prototype | Integrate Tree-sitter/language parsers | Point-lock required |
| Local LSP bridge prototype | Integrate LSP enrichment | Point-lock required |
| Enterprise indexing architecture | Defer SCIP/Kythe/CodeQL/Joern | Point-lock required |
| Workflow-canvas UI | Avoid | Do not use as core metaphor |

## Why this is the best decision

The primary research concludes that mature building blocks exist, but not a complete off-the-shelf product that matches the desired evidence-linked human/AI review cockpit. The missing layer is the product-specific substrate: stable code-object IDs, relation edges, evidence references, review findings, AI annotations, and bounded inspection views.

## MVP stack after approval

| layer | recommended path | gate |
|---|---|---|
| Object model | Custom `CodeObject`, `RelationEdge`, `EvidenceRef` | Product model review |
| Static demo data | JSON fixtures | Current static guardrails |
| Parser prototype | Tree-sitter / language-native APIs | Dependency gate |
| Semantic enrichment | LSP where server support is strong | Runtime-process gate |
| Visualization | D3 hierarchy, Cytoscape.js, optional ELK | Dependency gate |
| Export | Graphviz/Mermaid/PlantUML snapshots | Security/export gate |
| AI review | Evidence-linked annotations only | AI claim gate |

## Enterprise direction

Adopt a backend only after MVP value is validated. Candidate enterprise architecture uses SCIP-backed per-language indexes, optional Kythe-style storage/interchange, separate annotation/finding store, permission-aware evidence access, and optional CodeQL/Joern security overlays.

## Key risks

| risk | severity | mitigation |
|---|---|---|
| Static MVP scope creep | High | Use `MVP_SCOPE_LOCK.md` |
| Unsupported source claims | High | Use `CLAIM_TO_SOURCE_MATRIX.md` |
| Dependency approval gaps | High | Use `DEPENDENCY_GATE.md` |
| Sensitive code leakage | High | Use `SECURITY_PRIVACY_REVIEW_GATE.md` |
| Graph hairball UX | Medium | Enforce bounded selected-object graph |
| LSP variability | Medium | Treat LSP as enrichment, not sole truth |

## Readiness verdict

**READY_FOR_REVIEW / NOT_READY_FOR_IMPLEMENTATION**

The package is ready for Point/reviewer inspection and repo-persistence review. It is not an implementation approval.
