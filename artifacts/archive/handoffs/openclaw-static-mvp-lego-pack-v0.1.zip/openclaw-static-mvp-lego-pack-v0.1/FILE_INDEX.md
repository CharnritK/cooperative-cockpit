# File Index

| path | purpose |
|---|---|
| `.codex/goals/GOAL-004-lock-static-domain-model.md` | repo-drop lego artifact |
| `.codex/goals/GOAL-005-normalize-static-mock-data.md` | repo-drop lego artifact |
| `.codex/goals/GOAL-006-map-ui-to-locked-model.md` | repo-drop lego artifact |
| `.codex/goals/GOAL-007-work-packet-handoff-preview.md` | repo-drop lego artifact |
| `.codex/goals/GOAL-008-qa-hardening-evidence.md` | repo-drop lego artifact |
| `CHANGELOG.md` | repo-drop lego artifact |
| `PACKAGE_MANIFEST.json` | repo-drop lego artifact |
| `README_ASSIMILATION.md` | repo-drop lego artifact |
| `REVIEW_GATE.md` | repo-drop lego artifact |
| `artifacts/evidence/GOAL-004-validation-template.md` | repo-drop lego artifact |
| `artifacts/handoffs/OPENCLAW_STATIC_MVP_LEGO_HANDOFF.md` | repo-drop lego artifact |
| `artifacts/handoffs/openclaw-static-mvp-lego.manifest.json` | repo-drop lego artifact |
| `docs/product/BUILD_DEFER_KILL_REGISTER.md` | repo-drop lego artifact |
| `docs/product/CLAIM_REGISTER.md` | repo-drop lego artifact |
| `docs/product/CODEX_EXECUTION_SEQUENCE.md` | repo-drop lego artifact |
| `docs/product/GAP_BACKLOG.md` | repo-drop lego artifact |
| `docs/product/POINT_LOCK_DECISIONS.md` | repo-drop lego artifact |
| `docs/product/QA_OBJECT_MODEL_CHECKLIST.md` | repo-drop lego artifact |
| `docs/product/SCOPE_GUARDRAILS_AND_POINT_LOCKS.md` | repo-drop lego artifact |
| `docs/product/SOURCE_REGISTER.md` | repo-drop lego artifact |
| `docs/product/STATIC_MVP_GOLDEN_SCENARIO.md` | repo-drop lego artifact |
| `docs/product/STATIC_MVP_MOCK_DATA_SPEC.md` | repo-drop lego artifact |
| `docs/product/STATIC_MVP_OBJECT_MODEL.md` | repo-drop lego artifact |
| `docs/product/STATIC_MVP_ROADMAP.md` | repo-drop lego artifact |
| `docs/product/STATIC_MVP_SCREEN_MAP.md` | repo-drop lego artifact |
| `prompts/CODEX_STATIC_MVP_SCOPE_GUARDRAIL_PROMPT.md` | repo-drop lego artifact |
| `quality/STATIC_MVP_OBJECT_MODEL_QA_ADDENDUM.md` | repo-drop lego artifact |
