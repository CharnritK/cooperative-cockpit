# OpenClaw Static MVP Lego Pack v0.1

Created: 2026-05-30  
Target repo: `CharnritK/cooperative-cockpit`  
Package type: repo-drop planning and Codex handoff package  
Readiness: READY_WITH_ASSUMPTIONS

## Purpose

This package converts the OpenClaw static MVP synthesis into small, reviewable repo artifacts that Codex can assimilate in sequence.

It is intentionally a **lego pack**:

- Each file is independently useful.
- Each Codex goal is bounded.
- The first goal is documentation-only.
- Later goals are staged behind Point review.
- Nothing in this package requires backend, API, auth, database, deployment, runtime workflow execution, real agent orchestration, external connectors, MCP, or new dependencies.

## What this package contains

```text
docs/product/
  STATIC_MVP_ROADMAP.md
  STATIC_MVP_OBJECT_MODEL.md
  STATIC_MVP_SCREEN_MAP.md
  STATIC_MVP_MOCK_DATA_SPEC.md
  CODEX_EXECUTION_SEQUENCE.md
  SCOPE_GUARDRAILS_AND_POINT_LOCKS.md
  STATIC_MVP_GOLDEN_SCENARIO.md
  BUILD_DEFER_KILL_REGISTER.md
  POINT_LOCK_DECISIONS.md
  GAP_BACKLOG.md
  CLAIM_REGISTER.md
  SOURCE_REGISTER.md
  QA_OBJECT_MODEL_CHECKLIST.md

.codex/goals/
  GOAL-004-lock-static-domain-model.md
  GOAL-005-normalize-static-mock-data.md
  GOAL-006-map-ui-to-locked-model.md
  GOAL-007-work-packet-handoff-preview.md
  GOAL-008-qa-hardening-evidence.md

artifacts/handoffs/
  OPENCLAW_STATIC_MVP_LEGO_HANDOFF.md
  openclaw-static-mvp-lego.manifest.json

artifacts/evidence/
  GOAL-004-validation-template.md

quality/
  STATIC_MVP_OBJECT_MODEL_QA_ADDENDUM.md

prompts/
  CODEX_STATIC_MVP_SCOPE_GUARDRAIL_PROMPT.md
```

## Assimilation strategy

Recommended order:

1. Review this README and `REVIEW_GATE.md`.
2. Point decides whether `docs/product/**` is approved as the repo location for product lock docs.
3. Copy files into the repo root using the same relative paths.
4. Run only `GOAL-004-lock-static-domain-model.md` first.
5. Validate with `npm run validate`.
6. Run later goals only after Point approves the object model lock.

## Important boundary

This package does **not** implement the product.

It only provides:

- product lock docs;
- QA addenda;
- Codex goal prompts;
- handoff and validation templates;
- static mock-data specifications.

## Assumptions

- The repo remains the current static MVP repo.
- The static MVP app remains under `apps/static-mvp/`.
- Existing app pages remain eight pages:
  - Home
  - Workbench
  - Spec Builder
  - Review Runs
  - Preview
  - Decisions
  - Trace & Evidence
  - Rules & Scope
- `docs/product/**` is acceptable or will be approved by Point.
- Object-model Deep Research and Dify UX Deep Research are not stored in this package; this package uses the current synthesis and records that gap.

## Immediate next action

Run:

```text
.codex/goals/GOAL-004-lock-static-domain-model.md
```

Do **not** run GOAL-005 or later until GOAL-004 is reviewed.
