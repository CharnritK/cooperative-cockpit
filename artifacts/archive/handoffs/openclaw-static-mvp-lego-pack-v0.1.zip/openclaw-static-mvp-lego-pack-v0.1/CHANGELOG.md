# Changelog

## v0.1 — 2026-05-30

Initial lego pack.

Included:
- static MVP roadmap;
- locked object model;
- screen map;
- mock-data spec;
- Codex execution sequence;
- scope guardrails;
- Point-lock decision register;
- build/defer/kill register;
- gap/claim/source registers;
- five bounded Codex goals;
- handoff and validation templates.

No application code is included.
